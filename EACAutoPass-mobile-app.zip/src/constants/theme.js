export const COLORS = {
  // EAC Brand
  primary:    '#1565C0',
  primaryDark:'#0D47A1',
  primaryLight:'#1976D2',
  gold:       '#F2A900',
  goldDark:   '#D4920A',
  red:        '#C8102E',
  green:      '#2E7D32',
  greenLight: '#00C853',

  // UI
  white:      '#FFFFFF',
  background: '#F4F7FF',
  surface:    '#FFFFFF',
  surfaceAlt: '#EEF3FF',
  border:     '#DCE8FF',
  borderDark: '#B8CFEE',

  // Text
  textPrimary:   '#0D1B3E',
  textSecondary: '#4A5568',
  textMuted:     '#718096',
  textLight:     '#A0AEC0',

  // Status
  success:       '#00C853',
  successBg:     '#E8F5E9',
  warning:       '#F2A900',
  warningBg:     '#FFFBEE',
  error:         '#C8102E',
  errorBg:       '#FFEBEE',
  info:          '#1565C0',
  infoBg:        '#E3F2FD',
};

export const FONTS = {
  regular:   'System',
  medium:    'System',
  bold:      'System',
  sizes: {
    xs:   11,
    sm:   13,
    md:   15,
    lg:   17,
    xl:   20,
    xxl:  24,
    xxxl: 30,
    hero: 36,
  },
};

export const SPACING = {
  xs:  4,
  sm:  8,
  md:  12,
  lg:  16,
  xl:  20,
  xxl: 24,
  xxxl:32,
  section: 40,
};

export const RADIUS = {
  sm:  6,
  md:  10,
  lg:  14,
  xl:  20,
  full:999,
};

export const SHADOW = {
  card: {
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  modal: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 10,
  },
};

export const PERMIT_TYPES = [
  {
    key:   'TIP',
    label: 'Temporary Import',
    desc:  'Enter a foreign EAC country temporarily',
    icon:  'car',
    fee:   3500,
    color: '#1565C0',
  },
  {
    key:   'TEP',
    label: 'Temporary Export',
    desc:  'Leave your home country temporarily',
    icon:  'car-arrow-right',
    fee:   2000,
    color: '#2E7D32',
  },
  {
    key:   'TRANSIT',
    label: 'Transit Permit',
    desc:  'Pass through a country to final destination',
    icon:  'rotate',
    fee:   1500,
    color: '#7B1FA2',
  },
  {
    key:   'CARNET',
    label: 'Carnet de Passages',
    desc:  'Multi-country international travel document',
    icon:  'file-certificate',
    fee:   8000,
    color: '#E65100',
  },
];

export const BORDER_POSTS = [
  'Malaba (Kenya–Uganda)',
  'Busia (Kenya–Uganda)',
  'Namanga (Kenya–Tanzania)',
  'Taveta (Kenya–Tanzania)',
  'Isebania (Kenya–Tanzania)',
  'Gatuna (Rwanda–Uganda)',
  'Kagitumba (Uganda–Rwanda)',
  'Rusumo (Tanzania–Rwanda)',
  'Nimule (Uganda–South Sudan)',
  'Kobero (Tanzania–Burundi)',
];

export const EAC_COUNTRIES = [
  { code: 'KE', name: 'Kenya',       flag: '🇰🇪' },
  { code: 'UG', name: 'Uganda',      flag: '🇺🇬' },
  { code: 'TZ', name: 'Tanzania',    flag: '🇹🇿' },
  { code: 'RW', name: 'Rwanda',      flag: '🇷🇼' },
  { code: 'BI', name: 'Burundi',     flag: '🇧🇮' },
  { code: 'SS', name: 'South Sudan', flag: '🇸🇸' },
  { code: 'CD', name: 'DRC',         flag: '🇨🇩' },
];
