import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING } from '../constants/theme';

const QUICK_ACTIONS = [
  { icon: 'file-plus',     label: 'New Permit', color: COLORS.primary,  screen: 'Apply'     },
  { icon: 'qrcode-scan',   label: 'Scan QR',    color: COLORS.green,    screen: 'Scanner'   },
  { icon: 'card-multiple', label: 'My Permits', color: '#7B1FA2',       screen: 'MyPermits' },
  { icon: 'account-edit',  label: 'Profile',    color: COLORS.gold,     screen: 'Profile'   },
];

const ACTIVE_PERMITS = [
  {
    id:    'EAC-TIP-20491',
    type:  'Temporary Import',
    plate: 'KBZ 382 G',
    route: 'Kenya → Uganda',
    until: '30 Jun 2025',
    status:'valid',
  },
  {
    id:    'EAC-TEP-10322',
    type:  'Temporary Export',
    plate: 'KDA 101 K',
    route: 'Kenya → Tanzania',
    until: '15 Jun 2025',
    status:'expiring',
  },
];

const BORDER_TRAFFIC = [
  { name: 'Malaba',  count: 132, pct: 0.88, trend: 'up' },
  { name: 'Busia',   count: 94,  pct: 0.63, trend: 'down' },
  { name: 'Namanga', count: 61,  pct: 0.41, trend: 'up' },
  { name: 'Gatuna',  count: 48,  pct: 0.32, trend: 'down' },
];

export default function HomeScreen({ navigation }) {
  const insets    = useSafeAreaInsets();
  const [refresh, setRefresh] = useState(false);

  const onRefresh = () => {
    setRefresh(true);
    setTimeout(() => setRefresh(false), 1200);
  };

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top }]}
      contentContainerStyle={{ paddingBottom: 32 }}
      refreshControl={<RefreshControl refreshing={refresh} onRefresh={onRefresh} tintColor={COLORS.primary} />}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good morning,</Text>
          <Text style={styles.name}>John Mwangi 👋</Text>
        </View>
        <TouchableOpacity style={styles.notifBtn} activeOpacity={0.8}>
          <MaterialCommunityIcons name="bell-outline" size={22} color={COLORS.white} />
          <View style={styles.notifDot} />
        </TouchableOpacity>
      </View>

      {/* Status banner */}
      <View style={styles.statusBanner}>
        <View style={styles.statusLeft}>
          <View style={styles.statusDot} />
          <Text style={styles.statusText}>All border systems operational</Text>
        </View>
        <Text style={styles.statusTime}>Updated just now</Text>
      </View>

      {/* Quick actions */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
      </View>
      <View style={styles.quickActionsGrid}>
        {QUICK_ACTIONS.map((a, i) => (
          <TouchableOpacity
            key={i}
            style={styles.quickCard}
            onPress={() => navigation.navigate(a.screen)}
            activeOpacity={0.8}
          >
            <View style={[styles.quickIconWrap, { backgroundColor: a.color + '18' }]}>
              <MaterialCommunityIcons name={a.icon} size={26} color={a.color} />
            </View>
            <Text style={styles.quickLabel}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Active permits */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Active Permits</Text>
        <TouchableOpacity onPress={() => navigation.navigate('MyPermits')} activeOpacity={0.7}>
          <Text style={styles.seeAll}>See all</Text>
        </TouchableOpacity>
      </View>

      {ACTIVE_PERMITS.map(permit => (
        <TouchableOpacity
          key={permit.id}
          style={styles.permitCard}
          onPress={() => navigation.navigate('Permit', { permit })}
          activeOpacity={0.85}
        >
          <View style={styles.permitCardLeft}>
            <View style={[styles.permitStatusDot, {
              backgroundColor: permit.status === 'valid' ? COLORS.greenLight : COLORS.gold,
            }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.permitType}>{permit.type}</Text>
              <Text style={styles.permitPlate}>{permit.plate}</Text>
              <Text style={styles.permitRoute}>{permit.route}</Text>
            </View>
          </View>
          <View style={styles.permitCardRight}>
            <View style={[styles.permitBadge, {
              backgroundColor: permit.status === 'valid' ? COLORS.successBg : COLORS.warningBg,
            }]}>
              <Text style={[styles.permitBadgeText, {
                color: permit.status === 'valid' ? COLORS.success : COLORS.warning,
              }]}>
                {permit.status === 'valid' ? 'VALID' : 'EXPIRING'}
              </Text>
            </View>
            <Text style={styles.permitUntil}>Until {permit.until}</Text>
            <MaterialCommunityIcons name="chevron-right" size={18} color={COLORS.textMuted} />
          </View>
        </TouchableOpacity>
      ))}

      {/* Border traffic */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Live Border Traffic</Text>
        <View style={styles.liveBadge}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>LIVE</Text>
        </View>
      </View>

      <View style={styles.trafficCard}>
        {BORDER_TRAFFIC.map((b, i) => (
          <View key={i} style={[styles.trafficRow, i < BORDER_TRAFFIC.length - 1 && styles.trafficRowBorder]}>
            <Text style={styles.trafficName}>{b.name}</Text>
            <View style={styles.trafficBarWrap}>
              <View style={styles.trafficBar}>
                <View style={[styles.trafficFill, { width: `${b.pct * 100}%` }]} />
              </View>
              <Text style={styles.trafficCount}>{b.count}</Text>
              <MaterialCommunityIcons
                name={b.trend === 'up' ? 'trending-up' : 'trending-down'}
                size={14}
                color={b.trend === 'up' ? COLORS.red : COLORS.greenLight}
              />
            </View>
          </View>
        ))}
      </View>

      {/* Apply CTA */}
      <TouchableOpacity
        style={styles.applyCTA}
        onPress={() => navigation.navigate('Apply')}
        activeOpacity={0.88}
      >
        <MaterialCommunityIcons name="plus-circle" size={22} color={COLORS.white} />
        <Text style={styles.applyCTAText}>Apply for New Permit</Text>
        <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.white} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.background },
  header:          {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: COLORS.primary, paddingHorizontal: 20, paddingBottom: 20, paddingTop: 12,
  },
  greeting:        { fontSize: 13, color: 'rgba(255,255,255,0.75)', fontWeight: '500' },
  name:            { fontSize: 22, fontWeight: '800', color: COLORS.white, letterSpacing: -0.3 },
  notifBtn:        {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  notifDot:        {
    position: 'absolute', top: 8, right: 8,
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: COLORS.red, borderWidth: 1.5, borderColor: COLORS.primary,
  },
  statusBanner:    {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: COLORS.successBg, paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: 'rgba(0,200,83,0.15)',
  },
  statusLeft:      { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusDot:       { width: 7, height: 7, borderRadius: 4, backgroundColor: COLORS.greenLight },
  statusText:      { fontSize: 12, color: COLORS.green, fontWeight: '600' },
  statusTime:      { fontSize: 11, color: COLORS.textMuted },
  sectionHeader:   {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, marginTop: 20, marginBottom: 10,
  },
  sectionTitle:    { fontSize: 16, fontWeight: '800', color: COLORS.textPrimary },
  seeAll:          { fontSize: 13, color: COLORS.primary, fontWeight: '600' },
  quickActionsGrid:{ flexDirection: 'row', paddingHorizontal: 12, gap: 8 },
  quickCard:       {
    flex: 1, backgroundColor: COLORS.white,
    borderRadius: RADIUS.lg, padding: 14,
    alignItems: 'center', gap: 8,
    borderWidth: 1, borderColor: COLORS.border,
  },
  quickIconWrap:   { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  quickLabel:      { fontSize: 11, fontWeight: '600', color: COLORS.textSecondary, textAlign: 'center' },
  permitCard:      {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: COLORS.white, marginHorizontal: 16, marginBottom: 8,
    borderRadius: RADIUS.lg, padding: 14,
    borderWidth: 1, borderColor: COLORS.border,
  },
  permitCardLeft:  { flexDirection: 'row', alignItems: 'flex-start', gap: 12, flex: 1 },
  permitStatusDot: { width: 9, height: 9, borderRadius: 5, marginTop: 4 },
  permitType:      { fontSize: 13, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 2 },
  permitPlate:     { fontSize: 15, fontWeight: '800', color: COLORS.primary, letterSpacing: 1, marginBottom: 2 },
  permitRoute:     { fontSize: 12, color: COLORS.textMuted },
  permitCardRight: { alignItems: 'flex-end', gap: 4 },
  permitBadge:     { paddingHorizontal: 8, paddingVertical: 3, borderRadius: RADIUS.full },
  permitBadgeText: { fontSize: 10, fontWeight: '800', letterSpacing: 0.8 },
  permitUntil:     { fontSize: 11, color: COLORS.textMuted },
  liveBadge:       {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: COLORS.errorBg,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: RADIUS.full,
  },
  liveDot:         { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.red },
  liveText:        { fontSize: 10, fontWeight: '800', color: COLORS.red, letterSpacing: 1 },
  trafficCard:     {
    backgroundColor: COLORS.white, marginHorizontal: 16,
    borderRadius: RADIUS.lg, padding: 14,
    borderWidth: 1, borderColor: COLORS.border,
  },
  trafficRow:      { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  trafficRowBorder:{ borderBottomWidth: 1, borderBottomColor: COLORS.border },
  trafficName:     { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary, width: 70 },
  trafficBarWrap:  { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  trafficBar:      { flex: 1, height: 6, backgroundColor: COLORS.border, borderRadius: 3, overflow: 'hidden' },
  trafficFill:     { height: '100%', backgroundColor: COLORS.primary, borderRadius: 3 },
  trafficCount:    { fontSize: 12, fontWeight: '700', color: COLORS.textPrimary, width: 30, textAlign: 'right' },
  applyCTA:        {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: COLORS.primary, marginHorizontal: 16, marginTop: 20,
    height: 54, borderRadius: RADIUS.lg,
  },
  applyCTAText:    { fontSize: 16, fontWeight: '700', color: COLORS.white, flex: 1, textAlign: 'center' },
});
