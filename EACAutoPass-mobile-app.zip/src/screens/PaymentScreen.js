import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, Animated, ActivityIndicator,
  KeyboardAvoidingView, Platform, Vibration,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING } from '../constants/theme';

// ─── M-Pesa STK Service (mock + real structure) ───────────────────────────────
const MpesaService = {
  /**
   * Initiate M-Pesa STK Push
   * Production: calls your backend → Safaricom Daraja API
   *
   * POST /api/payments/mpesa/stkpush
   * Body: { phone, amount, accountRef, description }
   * Response: { checkoutRequestID, merchantRequestID, responseDescription }
   */
  async initiateSTK({ phone, amount, accountRef, description }) {
    // Normalize phone to 254XXXXXXXXX
    let normalised = phone.replace(/\s/g, '').replace(/^\+/, '');
    if (normalised.startsWith('0'))   normalised = '254' + normalised.slice(1);
    if (normalised.startsWith('7') || normalised.startsWith('1'))
      normalised = '254' + normalised;

    // ── REAL API CALL (uncomment in production) ──
    // const res = await fetch('https://api.eacautopass.com/payments/mpesa/stkpush', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    //   body: JSON.stringify({ phone: normalised, amount, accountRef, description }),
    // });
    // const data = await res.json();
    // return data; // { checkoutRequestID, responseDescription }

    // ── SIMULATION (remove in production) ──
    await new Promise(r => setTimeout(r, 1800));
    return {
      checkoutRequestID: 'ws_CO_' + Date.now(),
      merchantRequestID: 'MR_' + Math.random().toString(36).substr(2, 8).toUpperCase(),
      responseDescription: 'Success. Request accepted for processing',
      phone: normalised,
    };
  },

  /**
   * Poll payment status
   * POST /api/payments/mpesa/query
   */
  async queryStatus(checkoutRequestID) {
    // ── REAL API CALL (uncomment in production) ──
    // const res = await fetch('https://api.eacautopass.com/payments/mpesa/query', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    //   body: JSON.stringify({ checkoutRequestID }),
    // });
    // return await res.json();

    // ── SIMULATION: success after ~3 seconds ──
    await new Promise(r => setTimeout(r, 3000));
    return { resultCode: '0', resultDesc: 'The service request is processed successfully.' };
  },
};

// ─── Card formatter ────────────────────────────────────────────────────────────
const formatCardNumber = (v) =>
  v.replace(/\D/g, '').substring(0, 16).replace(/(.{4})/g, '$1 ').trim();
const formatExpiry = (v) => {
  const d = v.replace(/\D/g, '').substring(0, 4);
  return d.length > 2 ? d.substring(0, 2) + ' / ' + d.substring(2) : d;
};

// ─── STK Modal ─────────────────────────────────────────────────────────────────
function STKModal({ visible, phone, amount, permitId, onSuccess, onClose }) {
  const [stkState, setStkState] = useState('idle'); // idle | sending | waiting | success | failed | timeout
  const [countdown, setCountdown] = useState(60);
  const [resultMsg, setResultMsg] = useState('');
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const timerRef  = useRef(null);
  const pollRef   = useRef(null);
  const checkoutRef = useRef(null);

  useEffect(() => {
    if (visible) {
      setStkState('idle');
      setCountdown(60);
    }
    return () => {
      clearInterval(timerRef.current);
      clearTimeout(pollRef.current);
    };
  }, [visible]);

  useEffect(() => {
    if (stkState === 'waiting') {
      // Pulse animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.08, duration: 700, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1,    duration: 700, useNativeDriver: true }),
        ])
      ).start();

      // Countdown timer
      timerRef.current = setInterval(() => {
        setCountdown(c => {
          if (c <= 1) {
            clearInterval(timerRef.current);
            setStkState('timeout');
            return 0;
          }
          return c - 1;
        });
      }, 1000);

      // Poll for result
      pollRef.current = setTimeout(async () => {
        try {
          const result = await MpesaService.queryStatus(checkoutRef.current);
          clearInterval(timerRef.current);
          if (result.resultCode === '0') {
            setStkState('success');
            Vibration.vibrate([0, 80, 60, 80]);
            setTimeout(() => onSuccess(), 1600);
          } else {
            setStkState('failed');
            setResultMsg(result.resultDesc || 'Payment was cancelled or declined.');
          }
        } catch (err) {
          clearInterval(timerRef.current);
          setStkState('failed');
          setResultMsg('Network error. Please try again.');
        }
      }, 4000);
    }
    return () => {
      pulseAnim.stopAnimation();
      clearInterval(timerRef.current);
      clearTimeout(pollRef.current);
    };
  }, [stkState]);

  const sendSTK = async () => {
    setStkState('sending');
    try {
      const result = await MpesaService.initiateSTK({
        phone,
        amount,
        accountRef: permitId,
        description: 'EAC AutoPass Permit Fee',
      });
      checkoutRef.current = result.checkoutRequestID;
      setStkState('waiting');
    } catch (err) {
      setStkState('failed');
      setResultMsg('Could not send payment prompt. Check your number and try again.');
    }
  };

  const STATE_CONFIG = {
    idle: {
      icon:  'cellphone-nfc',
      color: COLORS.primary,
      title: 'Confirm M-Pesa Payment',
      desc:  `A payment request of KES ${amount?.toLocaleString()} will be sent to\n${phone}`,
    },
    sending: {
      icon:  'loading',
      color: COLORS.primary,
      title: 'Sending prompt...',
      desc:  'Connecting to M-Pesa. Please wait.',
    },
    waiting: {
      icon:  'cellphone-message',
      color: COLORS.greenLight,
      title: 'Check your phone!',
      desc:  'Enter your M-Pesa PIN to complete payment.\nPrompt expires in:',
    },
    success: {
      icon:  'check-circle',
      color: COLORS.greenLight,
      title: 'Payment Successful!',
      desc:  `KES ${amount?.toLocaleString()} received.\nYour permit is being issued...`,
    },
    failed: {
      icon:  'alert-circle',
      color: COLORS.red,
      title: 'Payment Failed',
      desc:  resultMsg || 'The payment was not completed.',
    },
    timeout: {
      icon:  'clock-alert',
      color: COLORS.gold,
      title: 'Prompt Expired',
      desc:  'The payment prompt timed out. Please try again.',
    },
  };

  const cfg = STATE_CONFIG[stkState] || STATE_CONFIG.idle;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={stkStyles.overlay}>
        <View style={stkStyles.sheet}>
          {/* Handle */}
          <View style={stkStyles.handle} />

          {/* Icon */}
          <Animated.View style={[
            stkStyles.iconCircle,
            { backgroundColor: cfg.color + '18' },
            stkState === 'waiting' && { transform: [{ scale: pulseAnim }] },
          ]}>
            {stkState === 'sending'
              ? <ActivityIndicator size="large" color={COLORS.primary} />
              : <MaterialCommunityIcons name={cfg.icon} size={52} color={cfg.color} />
            }
          </Animated.View>

          <Text style={stkStyles.title}>{cfg.title}</Text>
          <Text style={stkStyles.desc}>{cfg.desc}</Text>

          {/* Countdown */}
          {stkState === 'waiting' && (
            <View style={stkStyles.countdownWrap}>
              <Text style={stkStyles.countdown}>{countdown}s</Text>
              <View style={stkStyles.countdownBar}>
                <View style={[stkStyles.countdownFill, { width: `${(countdown / 60) * 100}%` }]} />
              </View>
            </View>
          )}

          {/* Phone display */}
          {(stkState === 'idle' || stkState === 'waiting') && (
            <View style={stkStyles.phonePill}>
              <MaterialCommunityIcons name="phone" size={16} color={COLORS.primary} />
              <Text style={stkStyles.phoneText}>{phone}</Text>
            </View>
          )}

          {/* Mpesa branding */}
          <View style={stkStyles.mpesaBrand}>
            <View style={stkStyles.mpesaDot} />
            <Text style={stkStyles.mpesaText}>Powered by M-Pesa</Text>
            <View style={stkStyles.mpesaDot} />
          </View>

          {/* Actions */}
          {stkState === 'idle' && (
            <TouchableOpacity style={stkStyles.btnSend} onPress={sendSTK} activeOpacity={0.88}>
              <MaterialCommunityIcons name="cellphone-arrow-down" size={20} color={COLORS.white} />
              <Text style={stkStyles.btnSendText}>Send M-Pesa Prompt</Text>
            </TouchableOpacity>
          )}
          {(stkState === 'failed' || stkState === 'timeout') && (
            <View style={stkStyles.retryRow}>
              <TouchableOpacity style={stkStyles.btnRetry} onPress={() => { setStkState('idle'); setCountdown(60); }} activeOpacity={0.85}>
                <Text style={stkStyles.btnRetryText}>Try Again</Text>
              </TouchableOpacity>
              <TouchableOpacity style={stkStyles.btnCancel} onPress={onClose} activeOpacity={0.85}>
                <Text style={stkStyles.btnCancelText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          )}
          {stkState === 'waiting' && (
            <TouchableOpacity style={stkStyles.btnCancelSm} onPress={() => { clearInterval(timerRef.current); setStkState('failed'); setResultMsg('Payment was cancelled by user.'); }} activeOpacity={0.7}>
              <Text style={stkStyles.btnCancelSmText}>Cancel payment</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
}

// ─── Main Payment Screen ───────────────────────────────────────────────────────
export default function PaymentScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { application } = route.params || {};
  const permit  = application?.permit;
  const fee     = permit?.fee || 0;

  const [selectedPM,  setSelectedPM]  = useState(null);
  const [mpesaPhone,  setMpesaPhone]  = useState(application?.phone || '');
  const [cardNo,      setCardNo]      = useState('');
  const [cardExpiry,  setCardExpiry]  = useState('');
  const [cardCVV,     setCardCVV]     = useState('');
  const [cardName,    setCardName]    = useState('');
  const [mobNetwork,  setMobNetwork]  = useState('');
  const [mobPhone,    setMobPhone]    = useState('');
  const [stkVisible,  setStkVisible]  = useState(false);
  const [processing,  setProcessing]  = useState(false);
  const [errors,      setErrors]      = useState({});

  const permitId = 'EAC-' + (permit?.key || 'TIP') + '-' + Math.floor(10000 + Math.random() * 90000);

  const validate = () => {
    const e = {};
    if (!selectedPM) { e.pm = 'Please select a payment method'; }
    if (selectedPM === 'card') {
      if (!cardNo.replace(/\s/g, '') || cardNo.replace(/\s/g, '').length < 16) e.cardNo = 'Enter valid 16-digit card number';
      if (!cardExpiry || cardExpiry.length < 7)  e.cardExpiry = 'Enter valid expiry date';
      if (!cardCVV    || cardCVV.length < 3)     e.cardCVV    = 'Enter 3-digit CVV';
      if (!cardName.trim())                       e.cardName   = 'Enter cardholder name';
    }
    if (selectedPM === 'mobile') {
      if (!mobNetwork) e.mobNetwork = 'Select your network';
      if (!mobPhone)   e.mobPhone   = 'Enter mobile number';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handlePay = () => {
    if (!validate()) return;
    if (selectedPM === 'mpesa') {
      if (!mpesaPhone.trim()) {
        setErrors({ mpesaPhone: 'Enter your M-Pesa phone number' });
        return;
      }
      setStkVisible(true);
    } else {
      // Simulate card / mobile payment
      setProcessing(true);
      setTimeout(() => {
        setProcessing(false);
        navigation.replace('Permit', { permitId, application });
      }, 2200);
    }
  };

  const onStkSuccess = () => {
    setStkVisible(false);
    navigation.replace('Permit', { permitId, application });
  };

  const PAYMENT_METHODS = [
    { key: 'mpesa',  icon: 'cellphone-nfc',      label: 'M-Pesa STK Push',  sub: 'Safaricom push-to-pay', color: '#00A651' },
    { key: 'card',   icon: 'credit-card',         label: 'Visa / Mastercard', sub: 'Secure card payment',  color: '#1A1F71' },
    { key: 'mobile', icon: 'cellphone',            label: 'Mobile Money',     sub: 'MTN, Airtel, Tigo',    color: '#FFCC00' },
    { key: 'bank',   icon: 'bank',                 label: 'Bank Transfer',    sub: 'KRA NCBA account',     color: COLORS.primary },
  ];

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="arrow-left" size={22} color={COLORS.white} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Payment</Text>
          <View style={styles.lockBadge}>
            <MaterialCommunityIcons name="lock" size={14} color={COLORS.white} />
            <Text style={styles.lockText}>Secure</Text>
          </View>
        </View>

        <ScrollView
          contentContainerStyle={{ paddingBottom: 120 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Application summary */}
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>Application Summary</Text>
            {[
              ['Applicant',    application?.name  || '—'],
              ['Vehicle',      [(application?.make||''), (application?.model||'')].filter(Boolean).join(' ') || '—'],
              ['Plate',        application?.plate || '—'],
              ['Permit Type',  permit?.label || '—'],
              ['Entry Border', application?.entryBorder || '—'],
            ].map(([lbl, val], i) => (
              <View key={i} style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>{lbl}</Text>
                <Text style={styles.summaryValue} numberOfLines={1}>{val}</Text>
              </View>
            ))}
            <View style={styles.summaryTotal}>
              <Text style={styles.summaryTotalLabel}>Total Fee</Text>
              <Text style={styles.summaryTotalValue}>KES {fee.toLocaleString()}</Text>
            </View>
          </View>

          {/* Payment methods */}
          <Text style={styles.sectionLabel}>Select Payment Method</Text>
          {errors.pm ? <Text style={styles.errorText}>{errors.pm}</Text> : null}

          {PAYMENT_METHODS.map(pm => (
            <TouchableOpacity
              key={pm.key}
              style={[styles.pmCard, selectedPM === pm.key && styles.pmCardSelected]}
              onPress={() => { setSelectedPM(pm.key); setErrors({}); }}
              activeOpacity={0.85}
            >
              <View style={[styles.pmIconWrap, { backgroundColor: pm.color + '18' }]}>
                <MaterialCommunityIcons name={pm.icon} size={24} color={pm.color} />
              </View>
              <View style={styles.pmInfo}>
                <Text style={styles.pmLabel}>{pm.label}</Text>
                <Text style={styles.pmSub}>{pm.sub}</Text>
              </View>
              <View style={[styles.pmRadio, selectedPM === pm.key && styles.pmRadioActive]}>
                {selectedPM === pm.key && <View style={styles.pmRadioDot} />}
              </View>
            </TouchableOpacity>
          ))}

          {/* M-Pesa form */}
          {selectedPM === 'mpesa' && (
            <View style={styles.pmFormCard}>
              <View style={styles.mpesaHeader}>
                <MaterialCommunityIcons name="cellphone-nfc" size={22} color="#00A651" />
                <Text style={styles.mpesaHeaderText}>M-Pesa STK Push</Text>
              </View>
              <Text style={styles.mpesaDesc}>
                We'll send a payment prompt directly to your Safaricom number.
                Enter your 4-digit M-Pesa PIN to confirm.
              </Text>
              <View style={styles.fieldWrap}>
                <Text style={styles.fieldLabel}>Safaricom Number *</Text>
                <View style={styles.inputRow}>
                  <View style={styles.countryCode}>
                    <Text style={styles.countryCodeText}>🇰🇪 +254</Text>
                  </View>
                  <TextInput
                    style={[styles.input, { flex: 1 }, errors.mpesaPhone && styles.inputError]}
                    placeholder="7XX XXX XXX"
                    placeholderTextColor={COLORS.textLight}
                    value={mpesaPhone}
                    onChangeText={setMpesaPhone}
                    keyboardType="phone-pad"
                    maxLength={12}
                  />
                </View>
                {errors.mpesaPhone ? <Text style={styles.errTxt}>{errors.mpesaPhone}</Text> : null}
              </View>
              <View style={styles.mpesaSteps}>
                {['Tap "Pay with M-Pesa" below', 'STK prompt appears on your phone', 'Enter your M-Pesa PIN', 'Payment confirmed instantly'].map((s, i) => (
                  <View key={i} style={styles.mpesaStep}>
                    <View style={styles.mpesaStepNum}><Text style={styles.mpesaStepNumText}>{i + 1}</Text></View>
                    <Text style={styles.mpesaStepText}>{s}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Card form */}
          {selectedPM === 'card' && (
            <View style={styles.pmFormCard}>
              <View style={styles.cardBrands}>
                <Text style={styles.cardBrand}>VISA</Text>
                <Text style={styles.cardBrandMC}>MC</Text>
              </View>
              {[
                { label: 'Card Number *', value: cardNo, onChange: v => setCardNo(formatCardNumber(v)), placeholder: '1234  5678  9012  3456', kb: 'numeric', error: errors.cardNo },
                { label: 'Cardholder Name *', value: cardName, onChange: setCardName, placeholder: 'Name on card', error: errors.cardName },
              ].map(f => (
                <View key={f.label} style={styles.fieldWrap}>
                  <Text style={styles.fieldLabel}>{f.label}</Text>
                  <TextInput style={[styles.input, f.error && styles.inputError]} placeholder={f.placeholder} placeholderTextColor={COLORS.textLight} value={f.value} onChangeText={f.onChange} keyboardType={f.kb || 'default'} />
                  {f.error ? <Text style={styles.errTxt}>{f.error}</Text> : null}
                </View>
              ))}
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <View style={[styles.fieldWrap, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Expiry *</Text>
                  <TextInput style={[styles.input, errors.cardExpiry && styles.inputError]} placeholder="MM / YY" placeholderTextColor={COLORS.textLight} value={cardExpiry} onChangeText={v => setCardExpiry(formatExpiry(v))} keyboardType="numeric" maxLength={7} />
                  {errors.cardExpiry ? <Text style={styles.errTxt}>{errors.cardExpiry}</Text> : null}
                </View>
                <View style={[styles.fieldWrap, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>CVV *</Text>
                  <TextInput style={[styles.input, errors.cardCVV && styles.inputError]} placeholder="123" placeholderTextColor={COLORS.textLight} value={cardCVV} onChangeText={setCardCVV} keyboardType="numeric" maxLength={3} secureTextEntry />
                  {errors.cardCVV ? <Text style={styles.errTxt}>{errors.cardCVV}</Text> : null}
                </View>
              </View>
            </View>
          )}

          {/* Mobile money form */}
          {selectedPM === 'mobile' && (
            <View style={styles.pmFormCard}>
              <Text style={styles.fieldLabel}>Select Network *</Text>
              <View style={styles.networkGrid}>
                {['MTN Mobile Money', 'Airtel Money', 'Tigo Pesa', 'Equitel'].map(n => (
                  <TouchableOpacity
                    key={n}
                    style={[styles.networkChip, mobNetwork === n && styles.networkChipActive]}
                    onPress={() => setMobNetwork(n)}
                    activeOpacity={0.8}
                  >
                    <Text style={[styles.networkChipText, mobNetwork === n && styles.networkChipTextActive]}>{n}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              {errors.mobNetwork ? <Text style={styles.errTxt}>{errors.mobNetwork}</Text> : null}
              <View style={[styles.fieldWrap, { marginTop: 12 }]}>
                <Text style={styles.fieldLabel}>Mobile Number *</Text>
                <TextInput style={[styles.input, errors.mobPhone && styles.inputError]} placeholder="+256 7XX XXX XXX" placeholderTextColor={COLORS.textLight} value={mobPhone} onChangeText={setMobPhone} keyboardType="phone-pad" />
                {errors.mobPhone ? <Text style={styles.errTxt}>{errors.mobPhone}</Text> : null}
              </View>
            </View>
          )}

          {/* Bank transfer */}
          {selectedPM === 'bank' && (
            <View style={styles.pmFormCard}>
              <Text style={styles.bankTitle}>Bank Transfer Details</Text>
              {[
                ['Bank',       'KRA — NCBA Bank Kenya'],
                ['Account No.','0100987654321'],
                ['Reference',  permitId],
                ['Amount',     'KES ' + fee.toLocaleString()],
              ].map(([lbl, val]) => (
                <View key={lbl} style={styles.bankRow}>
                  <Text style={styles.bankLabel}>{lbl}</Text>
                  <Text style={[styles.bankValue, lbl === 'Amount' && { color: COLORS.primary, fontWeight: '800' }]}>{val}</Text>
                </View>
              ))}
              <View style={styles.bankNote}>
                <MaterialCommunityIcons name="information" size={16} color={COLORS.primary} />
                <Text style={styles.bankNoteText}>
                  Upload proof of payment after transfer. Permit issued within 2 hours of confirmation.
                </Text>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Pay button */}
        <View style={[styles.payBarWrap, { paddingBottom: insets.bottom + 10 }]}>
          <TouchableOpacity
            style={[styles.payBtn, processing && { opacity: 0.75 }]}
            onPress={handlePay}
            disabled={processing}
            activeOpacity={0.88}
          >
            {processing
              ? <ActivityIndicator color={COLORS.white} size="small" />
              : <>
                  <MaterialCommunityIcons
                    name={selectedPM === 'mpesa' ? 'cellphone-arrow-down' : 'lock-check'}
                    size={20}
                    color={COLORS.white}
                  />
                  <Text style={styles.payBtnText}>
                    {selectedPM === 'mpesa'
                      ? `Pay KES ${fee.toLocaleString()} via M-Pesa`
                      : `Pay KES ${fee.toLocaleString()}`
                    }
                  </Text>
                </>
            }
          </TouchableOpacity>
        </View>
      </View>

      {/* STK Modal */}
      <STKModal
        visible={stkVisible}
        phone={mpesaPhone}
        amount={fee}
        permitId={permitId}
        onSuccess={onStkSuccess}
        onClose={() => setStkVisible(false)}
      />
    </KeyboardAvoidingView>
  );
}

// ─── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container:         { flex: 1, backgroundColor: COLORS.background },
  header:            { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.primary, paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  backBtn:           { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.15)' },
  headerTitle:       { flex: 1, fontSize: 18, fontWeight: '800', color: COLORS.white },
  lockBadge:         { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: RADIUS.full },
  lockText:          { fontSize: 11, color: COLORS.white, fontWeight: '600' },
  summaryCard:       { backgroundColor: COLORS.white, margin: 16, borderRadius: RADIUS.xl, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  summaryTitle:      { fontSize: 13, fontWeight: '800', color: COLORS.primary, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 12 },
  summaryRow:        { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  summaryLabel:      { fontSize: 12, color: COLORS.textMuted },
  summaryValue:      { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary, flex: 1, textAlign: 'right' },
  summaryTotal:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 10 },
  summaryTotalLabel: { fontSize: 15, fontWeight: '700', color: COLORS.textPrimary },
  summaryTotalValue: { fontSize: 22, fontWeight: '900', color: COLORS.primary },
  sectionLabel:      { fontSize: 13, fontWeight: '800', color: COLORS.textPrimary, textTransform: 'uppercase', letterSpacing: 0.8, marginHorizontal: 16, marginBottom: 8 },
  errorText:         { fontSize: 12, color: COLORS.red, marginHorizontal: 16, marginBottom: 8 },
  pmCard:            { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: COLORS.white, marginHorizontal: 16, marginBottom: 8, borderRadius: RADIUS.lg, padding: 14, borderWidth: 1.5, borderColor: COLORS.border },
  pmCardSelected:    { borderColor: COLORS.primary, backgroundColor: COLORS.infoBg },
  pmIconWrap:        { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  pmInfo:            { flex: 1 },
  pmLabel:           { fontSize: 14, fontWeight: '700', color: COLORS.textPrimary },
  pmSub:             { fontSize: 12, color: COLORS.textMuted, marginTop: 1 },
  pmRadio:           { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  pmRadioActive:     { borderColor: COLORS.primary },
  pmRadioDot:        { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.primary },
  pmFormCard:        { backgroundColor: COLORS.white, marginHorizontal: 16, marginBottom: 12, borderRadius: RADIUS.xl, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  fieldWrap:         { marginBottom: 12 },
  fieldLabel:        { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  inputRow:          { flexDirection: 'row', gap: 8 },
  countryCode:       { backgroundColor: COLORS.surfaceAlt, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.md, paddingHorizontal: 10, justifyContent: 'center' },
  countryCodeText:   { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  input:             { backgroundColor: COLORS.background, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.md, paddingHorizontal: 13, paddingVertical: 11, fontSize: 14, color: COLORS.textPrimary },
  inputError:        { borderColor: COLORS.red },
  errTxt:            { fontSize: 11, color: COLORS.red, marginTop: 3 },
  mpesaHeader:       { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  mpesaHeaderText:   { fontSize: 16, fontWeight: '800', color: '#00A651' },
  mpesaDesc:         { fontSize: 13, color: COLORS.textSecondary, lineHeight: 19, marginBottom: 14 },
  mpesaSteps:        { backgroundColor: COLORS.background, borderRadius: RADIUS.md, padding: 12, gap: 8, marginTop: 8 },
  mpesaStep:         { flexDirection: 'row', alignItems: 'center', gap: 10 },
  mpesaStepNum:      { width: 22, height: 22, borderRadius: 11, backgroundColor: '#00A651', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  mpesaStepNumText:  { fontSize: 11, fontWeight: '800', color: COLORS.white },
  mpesaStepText:     { fontSize: 12, color: COLORS.textSecondary, flex: 1 },
  cardBrands:        { flexDirection: 'row', gap: 8, marginBottom: 14 },
  cardBrand:         { backgroundColor: '#1A1F71', color: COLORS.white, paddingHorizontal: 12, paddingVertical: 4, borderRadius: RADIUS.sm, fontSize: 13, fontWeight: '900', overflow: 'hidden' },
  cardBrandMC:       { backgroundColor: '#EB001B', color: COLORS.white, paddingHorizontal: 12, paddingVertical: 4, borderRadius: RADIUS.sm, fontSize: 13, fontWeight: '900', overflow: 'hidden' },
  networkGrid:       { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  networkChip:       { paddingHorizontal: 12, paddingVertical: 7, borderRadius: RADIUS.full, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.background },
  networkChipActive: { borderColor: COLORS.primary, backgroundColor: COLORS.infoBg },
  networkChipText:   { fontSize: 13, fontWeight: '500', color: COLORS.textSecondary },
  networkChipTextActive: { color: COLORS.primary, fontWeight: '700' },
  bankTitle:         { fontSize: 14, fontWeight: '800', color: COLORS.primary, marginBottom: 12 },
  bankRow:           { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  bankLabel:         { fontSize: 12, color: COLORS.textMuted },
  bankValue:         { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  bankNote:          { flexDirection: 'row', gap: 8, backgroundColor: COLORS.infoBg, borderRadius: RADIUS.md, padding: 10, marginTop: 12, alignItems: 'flex-start' },
  bankNoteText:      { fontSize: 12, color: COLORS.primary, flex: 1, lineHeight: 18 },
  payBarWrap:        { backgroundColor: COLORS.white, borderTopWidth: 1, borderTopColor: COLORS.border, paddingHorizontal: 16, paddingTop: 12 },
  payBtn:            { height: 54, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  payBtnText:        { fontSize: 16, fontWeight: '800', color: COLORS.white },
});

const stkStyles = StyleSheet.create({
  overlay:        { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet:          { backgroundColor: COLORS.white, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 28, paddingBottom: 48, alignItems: 'center' },
  handle:         { width: 40, height: 4, borderRadius: 2, backgroundColor: COLORS.border, marginBottom: 24 },
  iconCircle:     { width: 96, height: 96, borderRadius: 48, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title:          { fontSize: 22, fontWeight: '800', color: COLORS.textPrimary, textAlign: 'center', marginBottom: 10 },
  desc:           { fontSize: 14, color: COLORS.textSecondary, textAlign: 'center', lineHeight: 22, marginBottom: 20 },
  countdownWrap:  { width: '100%', alignItems: 'center', marginBottom: 16 },
  countdown:      { fontSize: 36, fontWeight: '900', color: COLORS.primary, marginBottom: 8 },
  countdownBar:   { width: '80%', height: 6, backgroundColor: COLORS.border, borderRadius: 3, overflow: 'hidden' },
  countdownFill:  { height: '100%', backgroundColor: COLORS.primary, borderRadius: 3 },
  phonePill:      { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.infoBg, paddingHorizontal: 16, paddingVertical: 8, borderRadius: RADIUS.full, marginBottom: 20 },
  phoneText:      { fontSize: 15, fontWeight: '700', color: COLORS.primary },
  mpesaBrand:     { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 24 },
  mpesaDot:       { width: 24, height: 2, backgroundColor: '#00A651', borderRadius: 1 },
  mpesaText:      { fontSize: 12, color: '#00A651', fontWeight: '700', letterSpacing: 0.5 },
  btnSend:        { width: '100%', height: 52, backgroundColor: '#00A651', borderRadius: RADIUS.lg, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  btnSendText:    { fontSize: 16, fontWeight: '800', color: COLORS.white },
  retryRow:       { flexDirection: 'row', gap: 10, width: '100%' },
  btnRetry:       { flex: 1, height: 48, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg, alignItems: 'center', justifyContent: 'center' },
  btnRetryText:   { fontSize: 15, fontWeight: '700', color: COLORS.white },
  btnCancel:      { flex: 1, height: 48, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.lg, alignItems: 'center', justifyContent: 'center' },
  btnCancelText:  { fontSize: 15, fontWeight: '700', color: COLORS.textSecondary },
  btnCancelSm:    { marginTop: 8 },
  btnCancelSmText:{ fontSize: 13, color: COLORS.textMuted, textDecorationLine: 'underline' },
});
