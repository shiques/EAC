import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, KeyboardAvoidingView, Platform, Animated,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING } from '../constants/theme';
import { PERMIT_TYPES, BORDER_POSTS, EAC_COUNTRIES } from '../constants/theme';

const STEPS = ['Account', 'Vehicle', 'Documents', 'Permit', 'Review'];

const DOCS = [
  { key: 'logbook',   label: 'Vehicle Logbook',          required: true,  icon: 'book-open'       },
  { key: 'passport',  label: 'Passport / National ID',   required: true,  icon: 'passport'        },
  { key: 'insurance', label: 'COMESA Yellow Card',        required: true,  icon: 'shield-check'    },
  { key: 'roadlic',   label: 'Road License / Inspection', required: true,  icon: 'file-certificate'},
  { key: 'dl',        label: 'Driver\'s License',         required: true,  icon: 'card-account-details'},
  { key: 'carnet',    label: 'Carnet de Passages',        required: false, icon: 'file-document'   },
];

export default function ApplyScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [step, setStep]       = useState(0);
  const [errors, setErrors]   = useState({});

  // Step 1 - Account
  const [name,  setName]   = useState('');
  const [nat,   setNat]    = useState('');
  const [idNum, setIdNum]  = useState('');
  const [phone, setPhone]  = useState('');
  const [email, setEmail]  = useState('');

  // Step 2 - Vehicle
  const [plate,   setPlate]   = useState('');
  const [make,    setMake]    = useState('');
  const [model,   setModel]   = useState('');
  const [year,    setYear]    = useState('');
  const [chassis, setChassis] = useState('');

  // Step 3 - Documents
  const [uploadedDocs, setUploadedDocs] = useState({});

  // Step 4 - Permit
  const [selectedPT,    setSelectedPT]    = useState(null);
  const [entryBorder,   setEntryBorder]   = useState('');
  const [exitBorder,    setExitBorder]    = useState('');
  const [countries,     setCountries]     = useState([]);

  const toggleDoc = (key) => {
    setUploadedDocs(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleCountry = (code) => {
    setCountries(prev =>
      prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
    );
  };

  const validateStep = () => {
    const e = {};
    if (step === 0) {
      if (!name.trim())  e.name  = 'Full name is required';
      if (!idNum.trim()) e.idNum = 'ID / Passport number required';
      if (!phone.trim()) e.phone = 'Phone number is required';
    }
    if (step === 1) {
      if (!plate.trim())   e.plate   = 'Plate number required';
      if (!make.trim())    e.make    = 'Vehicle make required';
      if (!model.trim())   e.model   = 'Vehicle model required';
      if (!chassis.trim()) e.chassis = 'Chassis / VIN required';
    }
    if (step === 2) {
      const reqDocs = DOCS.filter(d => d.required);
      const missing = reqDocs.filter(d => !uploadedDocs[d.key]);
      if (missing.length > 0) e.docs = `Upload all ${reqDocs.length} required documents`;
    }
    if (step === 3) {
      if (!selectedPT)      e.permit = 'Select a permit type';
      if (!entryBorder)     e.entry  = 'Select entry border post';
      if (!exitBorder)      e.exit   = 'Select exit border post';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const goNext = () => {
    if (!validateStep()) return;
    if (step < STEPS.length - 1) {
      setStep(s => s + 1);
    } else {
      // Go to payment
      navigation.navigate('Payment', {
        application: {
          name, nat, idNum, phone, email,
          plate, make, model, year, chassis,
          uploadedDocs,
          permit: selectedPT,
          entryBorder, exitBorder, countries,
        },
      });
    }
  };

  const renderStepBar = () => (
    <View style={styles.stepBar}>
      {STEPS.map((label, i) => (
        <React.Fragment key={i}>
          <TouchableOpacity onPress={() => i < step && setStep(i)} activeOpacity={0.7}>
            <View style={styles.stepDotWrap}>
              <View style={[
                styles.stepDot,
                i < step  && styles.stepDotDone,
                i === step && styles.stepDotActive,
              ]}>
                {i < step
                  ? <MaterialCommunityIcons name="check" size={13} color={COLORS.white} />
                  : <Text style={[styles.stepNum, i === step && styles.stepNumActive]}>{i + 1}</Text>
                }
              </View>
              <Text style={[styles.stepLabel, i === step && styles.stepLabelActive]}>{label}</Text>
            </View>
          </TouchableOpacity>
          {i < STEPS.length - 1 && (
            <View style={[styles.stepLine, i < step && styles.stepLineDone]} />
          )}
        </React.Fragment>
      ))}
    </View>
  );

  const renderField = ({ label, value, onChange, placeholder, keyboardType = 'default', error, autoCapitalize }) => (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={[styles.fieldInput, error && styles.fieldInputError]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={COLORS.textLight}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize || 'sentences'}
      />
      {error ? <Text style={styles.fieldError}>{error}</Text> : null}
    </View>
  );

  const renderStep0 = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Your Details</Text>
      <Text style={styles.stepDesc}>Register using your national ID or passport</Text>
      {renderField({ label: 'Full Name *', value: name, onChange: setName, placeholder: 'e.g. John Mwangi Kamau', error: errors.name })}
      {renderField({ label: 'ID / Passport Number *', value: idNum, onChange: setIdNum, placeholder: 'e.g. A1234567', error: errors.idNum, autoCapitalize: 'characters' })}
      {renderField({ label: 'Phone Number *', value: phone, onChange: setPhone, placeholder: '+254 700 000 000', keyboardType: 'phone-pad', error: errors.phone })}
      {renderField({ label: 'Email (optional)', value: email, onChange: setEmail, placeholder: 'john@example.com', keyboardType: 'email-address' })}

      <Text style={styles.fieldLabel}>Nationality</Text>
      <View style={styles.countryChipsRow}>
        {EAC_COUNTRIES.map(c => (
          <TouchableOpacity
            key={c.code}
            style={[styles.countryChip, nat === c.name && styles.countryChipActive]}
            onPress={() => setNat(c.name)}
            activeOpacity={0.8}
          >
            <Text style={styles.countryChipFlag}>{c.flag}</Text>
            <Text style={[styles.countryChipText, nat === c.name && styles.countryChipTextActive]}>
              {c.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderStep1 = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Vehicle Details</Text>
      <Text style={styles.stepDesc}>Enter details exactly as they appear on your logbook</Text>
      {renderField({ label: 'Licence Plate *', value: plate, onChange: t => setPlate(t.toUpperCase()), placeholder: 'e.g. KBZ 382 G', error: errors.plate, autoCapitalize: 'characters' })}
      {renderField({ label: 'Vehicle Make *', value: make, onChange: setMake, placeholder: 'e.g. Toyota, Nissan', error: errors.make })}
      {renderField({ label: 'Model *', value: model, onChange: setModel, placeholder: 'e.g. Prado TX, Hilux', error: errors.model })}
      {renderField({ label: 'Year', value: year, onChange: setYear, placeholder: 'e.g. 2021', keyboardType: 'numeric' })}
      {renderField({ label: 'Chassis / VIN *', value: chassis, onChange: t => setChassis(t.toUpperCase()), placeholder: 'e.g. JTMHV05J904034812', error: errors.chassis, autoCapitalize: 'characters' })}
    </View>
  );

  const renderStep2 = () => {
    const reqCount  = DOCS.filter(d => d.required).length;
    const doneCount = DOCS.filter(d => d.required && uploadedDocs[d.key]).length;
    const pct       = doneCount / reqCount;
    return (
      <View style={styles.stepContent}>
        <Text style={styles.stepTitle}>Upload Documents</Text>
        <Text style={styles.stepDesc}>Tap each card to mark as uploaded</Text>

        {/* Progress */}
        <View style={styles.uploadProgressWrap}>
          <View style={styles.uploadProgressRow}>
            <Text style={styles.uploadProgressLabel}>{doneCount} of {reqCount} required documents</Text>
            <Text style={styles.uploadProgressPct}>{Math.round(pct * 100)}%</Text>
          </View>
          <View style={styles.uploadProgressBar}>
            <View style={[styles.uploadProgressFill, { width: `${pct * 100}%` }]} />
          </View>
        </View>

        {errors.docs ? <Text style={[styles.fieldError, { marginBottom: 12 }]}>{errors.docs}</Text> : null}

        <View style={styles.docsGrid}>
          {DOCS.map(doc => {
            const done = !!uploadedDocs[doc.key];
            return (
              <TouchableOpacity
                key={doc.key}
                style={[styles.docCard, done && styles.docCardDone]}
                onPress={() => toggleDoc(doc.key)}
                activeOpacity={0.8}
              >
                <View style={[styles.docIconWrap, { backgroundColor: done ? COLORS.successBg : COLORS.surfaceAlt }]}>
                  <MaterialCommunityIcons
                    name={done ? 'check-circle' : doc.icon}
                    size={24}
                    color={done ? COLORS.greenLight : COLORS.primary}
                  />
                </View>
                <Text style={styles.docLabel} numberOfLines={2}>{doc.label}</Text>
                <View style={[styles.docReqTag, { backgroundColor: doc.required ? COLORS.errorBg : COLORS.infoBg }]}>
                  <Text style={[styles.docReqText, { color: doc.required ? COLORS.red : COLORS.primary }]}>
                    {doc.required ? 'Required' : 'Optional'}
                  </Text>
                </View>
                <Text style={[styles.docStatus, { color: done ? COLORS.greenLight : COLORS.textMuted }]}>
                  {done ? '✓ Uploaded' : 'Tap to upload'}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {doneCount === reqCount && (
          <View style={styles.aiBox}>
            <MaterialCommunityIcons name="robot" size={22} color={COLORS.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.aiTitle}>AI Verification Complete</Text>
              {[
                ['Authenticity check',     '96%',  COLORS.greenLight],
                ['NTSA cross-check',       'PASS', COLORS.greenLight],
                ['Fraud risk score',       'LOW',  COLORS.greenLight],
                ['Blacklist status',       'CLEAR',COLORS.greenLight],
              ].map(([label, val, color], i) => (
                <View key={i} style={styles.aiRow}>
                  <Text style={styles.aiRowLabel}>{label}</Text>
                  <Text style={[styles.aiRowVal, { color }]}>{val}</Text>
                </View>
              ))}
            </View>
          </View>
        )}
      </View>
    );
  };

  const renderStep3 = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Permit Type & Route</Text>
      <Text style={styles.stepDesc}>Select the permit you need and define your travel route</Text>

      {errors.permit ? <Text style={styles.fieldError}>{errors.permit}</Text> : null}

      <View style={styles.permitGrid}>
        {PERMIT_TYPES.map(pt => (
          <TouchableOpacity
            key={pt.key}
            style={[styles.ptCard, selectedPT?.key === pt.key && styles.ptCardSelected]}
            onPress={() => setSelectedPT(pt)}
            activeOpacity={0.8}
          >
            <View style={[styles.ptIconWrap, { backgroundColor: pt.color + '18' }]}>
              <MaterialCommunityIcons name={pt.icon} size={22} color={pt.color} />
            </View>
            <Text style={styles.ptName}>{pt.label}</Text>
            <Text style={styles.ptFee}>KES {pt.fee.toLocaleString()}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Border posts */}
      <Text style={[styles.fieldLabel, { marginTop: 16 }]}>Entry Border Post *</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.borderChipsRow}>
        {BORDER_POSTS.map((b, i) => (
          <TouchableOpacity
            key={i}
            style={[styles.borderChip, entryBorder === b && styles.borderChipActive]}
            onPress={() => setEntryBorder(b)}
            activeOpacity={0.8}
          >
            <Text style={[styles.borderChipText, entryBorder === b && styles.borderChipTextActive]}>{b}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      {errors.entry ? <Text style={styles.fieldError}>{errors.entry}</Text> : null}

      <Text style={[styles.fieldLabel, { marginTop: 12 }]}>Exit Border Post *</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.borderChipsRow}>
        {BORDER_POSTS.map((b, i) => (
          <TouchableOpacity
            key={i}
            style={[styles.borderChip, exitBorder === b && styles.borderChipActive]}
            onPress={() => setExitBorder(b)}
            activeOpacity={0.8}
          >
            <Text style={[styles.borderChipText, exitBorder === b && styles.borderChipTextActive]}>{b}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      {errors.exit ? <Text style={styles.fieldError}>{errors.exit}</Text> : null}

      {/* Countries */}
      <Text style={[styles.fieldLabel, { marginTop: 16 }]}>Countries to Visit</Text>
      <View style={styles.countryChipsRow}>
        {EAC_COUNTRIES.map(c => (
          <TouchableOpacity
            key={c.code}
            style={[styles.countryChip, countries.includes(c.code) && styles.countryChipActive]}
            onPress={() => toggleCountry(c.code)}
            activeOpacity={0.8}
          >
            <Text style={styles.countryChipFlag}>{c.flag}</Text>
            <Text style={[styles.countryChipText, countries.includes(c.code) && styles.countryChipTextActive]}>
              {c.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderStep4 = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Review Application</Text>
      <Text style={styles.stepDesc}>Check your details before proceeding to payment</Text>

      {[
        { label: 'Applicant',    value: name  || '—' },
        { label: 'ID Number',    value: idNum || '—' },
        { label: 'Phone',        value: phone || '—' },
        { label: 'Vehicle',      value: [make, model].filter(Boolean).join(' ') || '—' },
        { label: 'Plate No.',    value: plate || '—' },
        { label: 'Permit Type',  value: selectedPT?.label || '—' },
        { label: 'Entry Border', value: entryBorder || '—' },
        { label: 'Exit Border',  value: exitBorder  || '—' },
        { label: 'Fee',          value: selectedPT ? `KES ${selectedPT.fee.toLocaleString()}` : '—' },
      ].map(({ label, value }, i) => (
        <View key={i} style={[styles.reviewRow, i % 2 === 0 && styles.reviewRowAlt]}>
          <Text style={styles.reviewLabel}>{label}</Text>
          <Text style={styles.reviewValue} numberOfLines={1}>{value}</Text>
        </View>
      ))}

      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>Total Fee</Text>
        <Text style={styles.totalValue}>
          {selectedPT ? `KES ${selectedPT.fee.toLocaleString()}` : '—'}
        </Text>
      </View>
    </View>
  );

  const renderCurrentStep = () => {
    switch (step) {
      case 0: return renderStep0();
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      default: return null;
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>New Permit Application</Text>
          <Text style={styles.headerSub}>Step {step + 1} of {STEPS.length}</Text>
        </View>

        {/* Step bar */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.stepBarWrap} contentContainerStyle={{ paddingHorizontal: 16 }}>
          {renderStepBar()}
        </ScrollView>

        {/* Content */}
        <ScrollView
          style={styles.scrollArea}
          contentContainerStyle={{ paddingBottom: 120 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {renderCurrentStep()}
        </ScrollView>

        {/* Bottom nav */}
        <View style={[styles.bottomNav, { paddingBottom: insets.bottom + 8 }]}>
          {step > 0 && (
            <TouchableOpacity style={styles.btnBack} onPress={() => setStep(s => s - 1)} activeOpacity={0.8}>
              <MaterialCommunityIcons name="arrow-left" size={18} color={COLORS.primary} />
              <Text style={styles.btnBackText}>Back</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.btnNext, step === 0 && { flex: 1 }]}
            onPress={goNext}
            activeOpacity={0.88}
          >
            <Text style={styles.btnNextText}>
              {step === STEPS.length - 1 ? 'Proceed to Payment' : 'Continue'}
            </Text>
            <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.white} />
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.background },
  header:          { backgroundColor: COLORS.primary, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14 },
  headerTitle:     { fontSize: 20, fontWeight: '800', color: COLORS.white },
  headerSub:       { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  stepBarWrap:     { backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border, maxHeight: 72 },
  stepBar:         { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  stepDotWrap:     { alignItems: 'center', gap: 4 },
  stepDot:         { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  stepDotActive:   { backgroundColor: COLORS.primary },
  stepDotDone:     { backgroundColor: COLORS.greenLight },
  stepNum:         { fontSize: 12, fontWeight: '700', color: COLORS.textMuted },
  stepNumActive:   { color: COLORS.white },
  stepLabel:       { fontSize: 9, color: COLORS.textMuted, fontWeight: '500', letterSpacing: 0.2 },
  stepLabelActive: { color: COLORS.primary, fontWeight: '700' },
  stepLine:        { flex: 1, height: 2, backgroundColor: COLORS.border, minWidth: 16, maxWidth: 32 },
  stepLineDone:    { backgroundColor: COLORS.greenLight },
  scrollArea:      { flex: 1 },
  stepContent:     { padding: 16 },
  stepTitle:       { fontSize: 22, fontWeight: '800', color: COLORS.textPrimary, marginBottom: 4 },
  stepDesc:        { fontSize: 13, color: COLORS.textMuted, marginBottom: 20 },
  fieldWrap:       { marginBottom: 14 },
  fieldLabel:      { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 5 },
  fieldInput:      { backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.md, paddingHorizontal: 13, paddingVertical: 11, fontSize: 14, color: COLORS.textPrimary },
  fieldInputError: { borderColor: COLORS.red },
  fieldError:      { fontSize: 11, color: COLORS.red, marginTop: 4 },
  countryChipsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginBottom: 8 },
  countryChip:     { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 6, borderRadius: RADIUS.full, borderWidth: 1.5, borderColor: COLORS.border, backgroundColor: COLORS.white },
  countryChipActive:{ borderColor: COLORS.primary, backgroundColor: COLORS.infoBg },
  countryChipFlag: { fontSize: 14 },
  countryChipText: { fontSize: 12, color: COLORS.textSecondary, fontWeight: '500' },
  countryChipTextActive: { color: COLORS.primary, fontWeight: '700' },
  uploadProgressWrap: { backgroundColor: COLORS.white, borderRadius: RADIUS.md, padding: 12, marginBottom: 14, borderWidth: 1, borderColor: COLORS.border },
  uploadProgressRow:  { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 7 },
  uploadProgressLabel:{ fontSize: 12, color: COLORS.textSecondary, fontWeight: '500' },
  uploadProgressPct:  { fontSize: 12, fontWeight: '700', color: COLORS.primary },
  uploadProgressBar:  { height: 6, backgroundColor: COLORS.border, borderRadius: 3, overflow: 'hidden' },
  uploadProgressFill: { height: '100%', backgroundColor: COLORS.primary, borderRadius: 3 },
  docsGrid:        { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  docCard:         { width: '47%', backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: 12, alignItems: 'center', gap: 6, borderWidth: 2, borderColor: COLORS.border, borderStyle: 'dashed' },
  docCardDone:     { borderColor: COLORS.greenLight, borderStyle: 'solid', backgroundColor: COLORS.successBg },
  docIconWrap:     { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  docLabel:        { fontSize: 11, fontWeight: '600', color: COLORS.textPrimary, textAlign: 'center' },
  docReqTag:       { paddingHorizontal: 7, paddingVertical: 2, borderRadius: RADIUS.full },
  docReqText:      { fontSize: 9, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  docStatus:       { fontSize: 10, fontWeight: '600' },
  aiBox:           { flexDirection: 'row', gap: 12, backgroundColor: COLORS.successBg, borderRadius: RADIUS.lg, padding: 14, marginTop: 12, borderWidth: 1, borderColor: 'rgba(0,200,83,0.25)' },
  aiTitle:         { fontSize: 13, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 8 },
  aiRow:           { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  aiRowLabel:      { fontSize: 12, color: COLORS.textSecondary },
  aiRowVal:        { fontSize: 12, fontWeight: '700' },
  permitGrid:      { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 8 },
  ptCard:          { width: '47%', backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: 12, alignItems: 'center', gap: 7, borderWidth: 1.5, borderColor: COLORS.border },
  ptCardSelected:  { borderColor: COLORS.primary, backgroundColor: COLORS.infoBg },
  ptIconWrap:      { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  ptName:          { fontSize: 12, fontWeight: '700', color: COLORS.textPrimary, textAlign: 'center' },
  ptFee:           { fontSize: 13, fontWeight: '800', color: COLORS.primary },
  borderChipsRow:  { marginBottom: 4 },
  borderChip:      { paddingHorizontal: 12, paddingVertical: 7, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white, marginRight: 7 },
  borderChipActive:{ borderColor: COLORS.primary, backgroundColor: COLORS.infoBg },
  borderChipText:  { fontSize: 12, color: COLORS.textSecondary, fontWeight: '500', whiteSpace: 'nowrap' },
  borderChipTextActive: { color: COLORS.primary, fontWeight: '700' },
  reviewRow:       { flexDirection: 'row', justifyContent: 'space-between', padding: 11, borderRadius: RADIUS.md },
  reviewRowAlt:    { backgroundColor: COLORS.surfaceAlt },
  reviewLabel:     { fontSize: 12, color: COLORS.textMuted, fontWeight: '500' },
  reviewValue:     { fontSize: 13, fontWeight: '700', color: COLORS.textPrimary, flex: 1, textAlign: 'right' },
  totalRow:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg, marginTop: 12 },
  totalLabel:      { fontSize: 15, fontWeight: '700', color: COLORS.white },
  totalValue:      { fontSize: 20, fontWeight: '900', color: COLORS.gold },
  bottomNav:       { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingTop: 12, backgroundColor: COLORS.white, borderTopWidth: 1, borderTopColor: COLORS.border },
  btnBack:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: 18, height: 50, borderRadius: RADIUS.lg, borderWidth: 1.5, borderColor: COLORS.primary },
  btnBackText:     { fontSize: 14, fontWeight: '700', color: COLORS.primary },
  btnNext:         { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 50, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg },
  btnNextText:     { fontSize: 15, fontWeight: '800', color: COLORS.white },
});
