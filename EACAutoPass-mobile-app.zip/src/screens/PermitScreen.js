import React, { useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Share,
  Animated,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS } from '../constants/theme';

const QRBlock = ({ value }) => {
  const seed = [...(value || 'EAC')].reduce((a, c) => ((a << 5) - a + c.charCodeAt(0)) | 0, 0);
  const COLS = [COLORS.primary, COLORS.gold, COLORS.red, COLORS.green, '#7B1FA2'];
  const SIZE = 9;
  const cells = Array.from({ length: SIZE * SIZE }, (_, i) => {
    const row = Math.floor(i / SIZE);
    const col = i % SIZE;
    const isCorner =
      (row < 3 && col < 3) || (row < 3 && col >= SIZE - 3) || (row >= SIZE - 3 && col < 3);
    if (isCorner) return { filled: true, color: COLORS.primary };
    const s = Math.abs(((seed ^ (row * 97 + col * 31)) * 2654435761) >>> 0);
    return { filled: s % 3 !== 0, color: COLS[s % COLS.length] };
  });

  return (
    <View style={qrStyles.grid}>
      {cells.map((c, i) => (
        <View
          key={i}
          style={[qrStyles.cell, { backgroundColor: c.filled ? c.color : 'transparent' }]}
        />
      ))}
    </View>
  );
};

const qrStyles = StyleSheet.create({
  grid: { width: 108, height: 108, flexDirection: 'row', flexWrap: 'wrap', padding: 6, backgroundColor: COLORS.white, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border },
  cell: { width: '11.11%', aspectRatio: 1, borderRadius: 1 },
});

export default function PermitScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { permitId, application } = route.params || {};
  const app    = application || {};
  const permit = app.permit || {};
  const name   = app.name   || 'John Mwangi Kamau';
  const plate  = app.plate  || 'KBZ 382 G';
  const make   = app.make   || 'Toyota';
  const model  = app.model  || 'Prado TX';
  const entry  = app.entryBorder || 'Malaba (Kenya–Uganda)';
  const exit   = app.exitBorder  || 'Namanga (Kenya–Tanzania)';
  const id     = permitId        || 'EAC-TIP-20491';

  const checkScale = useRef(new Animated.Value(0)).current;
  const cardOpacity = useRef(new Animated.Value(0)).current;
  const cardTransY  = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.spring(checkScale, { toValue: 1, tension: 60, friction: 6, useNativeDriver: true }),
      Animated.parallel([
        Animated.timing(cardOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardTransY,  { toValue: 0, duration: 400, useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  const handleShare = () => {
    Share.share({
      message: `EAC AutoPass Permit\nID: ${id}\nVehicle: ${plate}\nHolder: ${name}\nRoute: ${entry} → ${exit}\nStatus: APPROVED ✓`,
      title:   'My EAC AutoPass Permit',
    });
  };

  const today  = new Date().toLocaleDateString('en-KE', { day: '2-digit', month: 'short', year: 'numeric' });
  const expiry = new Date(Date.now() + 30 * 86400000).toLocaleDateString('en-KE', { day: '2-digit', month: 'short', year: 'numeric' });

  const FIELDS = [
    { label: 'Permit Holder',  value: name,                icon: 'account'         },
    { label: 'Vehicle',        value: `${make} ${model}`,  icon: 'car'             },
    { label: 'Plate No.',      value: plate,               icon: 'card-text'       },
    { label: 'Entry Border',   value: entry,               icon: 'map-marker-down' },
    { label: 'Exit Border',    value: exit,                icon: 'map-marker-up'   },
    { label: 'Issued',         value: today,               icon: 'calendar-check'  },
    { label: 'Expires',        value: expiry,              icon: 'calendar-alert'  },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Success banner */}
        <View style={styles.banner}>
          <Animated.View style={[styles.checkCircle, { transform: [{ scale: checkScale }] }]}>
            <MaterialCommunityIcons name="check-bold" size={36} color={COLORS.white} />
          </Animated.View>
          <Text style={styles.bannerTitle}>Permit Approved!</Text>
          <Text style={styles.bannerSub}>
            Your permit is active and synced to all border posts.{'\n'}
            Show the QR code for instant clearance.
          </Text>
        </View>

        {/* Permit card */}
        <Animated.View style={[styles.permitCard, { opacity: cardOpacity, transform: [{ translateY: cardTransY }] }]}>
          {/* Card header */}
          <View style={styles.cardHeader}>
            <View>
              <Text style={styles.cardPermitType}>{(permit.label || 'TEMPORARY IMPORT PERMIT').toUpperCase()}</Text>
              <Text style={styles.cardPermitId}>{id}</Text>
            </View>
            <View style={styles.approvedBadge}>
              <MaterialCommunityIcons name="check-circle" size={12} color={COLORS.greenLight} />
              <Text style={styles.approvedText}>APPROVED</Text>
            </View>
          </View>

          {/* Card body */}
          <View style={styles.cardBody}>
            <View style={styles.fieldsCol}>
              {FIELDS.map(({ label, value, icon }, i) => (
                <View key={i} style={styles.fieldRow}>
                  <MaterialCommunityIcons name={icon} size={14} color={COLORS.primary} style={styles.fieldIcon} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.fieldLabel}>{label}</Text>
                    <Text style={styles.fieldValue} numberOfLines={1}>{value}</Text>
                  </View>
                </View>
              ))}
            </View>

            {/* QR + plate */}
            <View style={styles.qrCol}>
              <QRBlock value={id + '|' + plate} />
              <Text style={styles.plateTxt}>{plate}</Text>
              <Text style={styles.scanHint}>Scan at border</Text>
            </View>
          </View>

          {/* Card footer */}
          <View style={styles.cardFooter}>
            <View style={styles.footerItem}>
              <MaterialCommunityIcons name="lock" size={12} color={COLORS.primary} />
              <Text style={styles.footerItemText}>Cryptographically signed</Text>
            </View>
            <View style={styles.footerItem}>
              <MaterialCommunityIcons name="wifi" size={12} color={COLORS.primary} />
              <Text style={styles.footerItemText}>Synced to all borders</Text>
            </View>
            <View style={styles.footerItem}>
              <MaterialCommunityIcons name="cellphone" size={12} color={COLORS.primary} />
              <Text style={styles.footerItemText}>e-Permit wallet</Text>
            </View>
          </View>
        </Animated.View>

        {/* Status checks */}
        <View style={styles.statusGrid}>
          {[
            { icon: 'shield-check',    label: 'COMESA Insurance', status: 'Verified',  ok: true  },
            { icon: 'car-info',        label: 'NTSA Vehicle',     status: 'Verified',  ok: true  },
            { icon: 'account-check',   label: 'ID Verification',  status: 'Passed',    ok: true  },
            { icon: 'alert-circle',    label: 'Blacklist Check',  status: 'Clear',     ok: true  },
          ].map(({ icon, label, status, ok }, i) => (
            <View key={i} style={styles.statusCard}>
              <MaterialCommunityIcons name={icon} size={20} color={ok ? COLORS.greenLight : COLORS.red} />
              <Text style={styles.statusLabel}>{label}</Text>
              <Text style={[styles.statusVal, { color: ok ? COLORS.greenLight : COLORS.red }]}>{status}</Text>
            </View>
          ))}
        </View>

        {/* Countries */}
        {app.countries && app.countries.length > 0 && (
          <View style={styles.countriesCard}>
            <Text style={styles.countriesTitle}>Authorised Countries</Text>
            <View style={styles.countriesRow}>
              {app.countries.map(code => {
                const found = [
                  { code: 'KE', name: 'Kenya', flag: '🇰🇪' },
                  { code: 'UG', name: 'Uganda', flag: '🇺🇬' },
                  { code: 'TZ', name: 'Tanzania', flag: '🇹🇿' },
                  { code: 'RW', name: 'Rwanda', flag: '🇷🇼' },
                  { code: 'BI', name: 'Burundi', flag: '🇧🇮' },
                  { code: 'SS', name: 'South Sudan', flag: '🇸🇸' },
                  { code: 'CD', name: 'DRC', flag: '🇨🇩' },
                ].find(c => c.code === code);
                return found ? (
                  <View key={code} style={styles.countryPill}>
                    <Text>{found.flag}</Text>
                    <Text style={styles.countryPillText}>{found.name}</Text>
                  </View>
                ) : null;
              })}
            </View>
          </View>
        )}
      </ScrollView>

      {/* Action buttons */}
      <View style={[styles.actions, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity style={styles.btnShare} onPress={handleShare} activeOpacity={0.85}>
          <MaterialCommunityIcons name="share-variant" size={18} color={COLORS.primary} />
          <Text style={styles.btnShareText}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.btnDone}
          onPress={() => navigation.navigate('Main', { screen: 'MyPermits' })}
          activeOpacity={0.88}
        >
          <Text style={styles.btnDoneText}>View My Permits</Text>
          <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.white} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.background },
  banner:          { backgroundColor: COLORS.primary, alignItems: 'center', paddingHorizontal: 24, paddingTop: 24, paddingBottom: 32 },
  checkCircle:     { width: 68, height: 68, borderRadius: 34, backgroundColor: COLORS.greenLight, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  bannerTitle:     { fontSize: 26, fontWeight: '900', color: COLORS.white, marginBottom: 8 },
  bannerSub:       { fontSize: 13, color: 'rgba(255,255,255,0.72)', textAlign: 'center', lineHeight: 20 },
  permitCard:      { backgroundColor: COLORS.white, margin: 16, borderRadius: RADIUS.xl, overflow: 'hidden', borderWidth: 1.5, borderColor: COLORS.primary, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 16, elevation: 6 },
  cardHeader:      { backgroundColor: COLORS.primary, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardPermitType:  { fontSize: 10, color: 'rgba(255,255,255,0.65)', letterSpacing: 1.2, marginBottom: 4 },
  cardPermitId:    { fontSize: 18, fontWeight: '800', color: COLORS.white, letterSpacing: 1.5 },
  approvedBadge:   { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(0,200,83,0.2)', paddingHorizontal: 10, paddingVertical: 5, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.greenLight },
  approvedText:    { fontSize: 10, fontWeight: '800', color: COLORS.greenLight, letterSpacing: 0.5 },
  cardBody:        { flexDirection: 'row', padding: 14, gap: 12 },
  fieldsCol:       { flex: 1, gap: 8 },
  fieldRow:        { flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  fieldIcon:       { marginTop: 2, flexShrink: 0 },
  fieldLabel:      { fontSize: 9, color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.4 },
  fieldValue:      { fontSize: 12, fontWeight: '700', color: COLORS.textPrimary, marginTop: 1 },
  qrCol:           { alignItems: 'center', gap: 6, flexShrink: 0 },
  plateTxt:        { fontFamily: 'System', fontSize: 13, fontWeight: '800', color: COLORS.primary, letterSpacing: 2 },
  scanHint:        { fontSize: 9, color: COLORS.textMuted },
  cardFooter:      { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 10, paddingHorizontal: 12, backgroundColor: COLORS.infoBg, borderTopWidth: 1, borderTopColor: COLORS.border },
  footerItem:      { flexDirection: 'row', alignItems: 'center', gap: 4 },
  footerItemText:  { fontSize: 9, color: COLORS.primary, fontWeight: '500' },
  statusGrid:      { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginHorizontal: 16, marginBottom: 12 },
  statusCard:      { flex: 1, minWidth: '44%', backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: 12, alignItems: 'center', gap: 5, borderWidth: 1, borderColor: COLORS.border },
  statusLabel:     { fontSize: 11, color: COLORS.textSecondary, fontWeight: '500', textAlign: 'center' },
  statusVal:       { fontSize: 12, fontWeight: '800' },
  countriesCard:   { backgroundColor: COLORS.white, marginHorizontal: 16, borderRadius: RADIUS.lg, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  countriesTitle:  { fontSize: 12, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.5 },
  countriesRow:    { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  countryPill:     { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, backgroundColor: COLORS.infoBg, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border },
  countryPillText: { fontSize: 12, color: COLORS.primary, fontWeight: '600' },
  actions:         { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingTop: 12, backgroundColor: COLORS.white, borderTopWidth: 1, borderTopColor: COLORS.border },
  btnShare:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 50, paddingHorizontal: 20, borderRadius: RADIUS.lg, borderWidth: 1.5, borderColor: COLORS.primary },
  btnShareText:    { fontSize: 14, fontWeight: '700', color: COLORS.primary },
  btnDone:         { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 50, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg },
  btnDoneText:     { fontSize: 15, fontWeight: '800', color: COLORS.white },
});
