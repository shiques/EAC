import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS } from '../constants/theme';

export default function ProfileScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState(true);
  const [biometric,     setBiometric]     = useState(true);

  const MENU = [
    {
      section: 'Account',
      items: [
        { icon: 'account-edit',      label: 'Edit Profile',        onPress: () => {} },
        { icon: 'car-multiple',      label: 'My Vehicles',         onPress: () => {} },
        { icon: 'file-document',     label: 'My Documents',        onPress: () => {} },
        { icon: 'shield-key',        label: 'Security & Password', onPress: () => {} },
      ],
    },
    {
      section: 'Preferences',
      items: [
        { icon: 'bell',        label: 'Permit Expiry Alerts', toggle: true, value: notifications, onToggle: setNotifications },
        { icon: 'fingerprint', label: 'Biometric Login',      toggle: true, value: biometric,     onToggle: setBiometric     },
        { icon: 'translate',   label: 'Language',             badge: 'English',         onPress: () => {} },
      ],
    },
    {
      section: 'Support',
      items: [
        { icon: 'help-circle',      label: 'Help & FAQ',             onPress: () => {} },
        { icon: 'phone',            label: 'Contact Support',        onPress: () => {} },
        { icon: 'file-text',        label: 'Terms & Privacy',        onPress: () => {} },
        { icon: 'information',      label: 'App Version 1.0.0',      onPress: () => {}, muted: true },
      ],
    },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 24 }} showsVerticalScrollIndicator={false}>
        {/* Avatar card */}
        <View style={styles.avatarCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarInitials}>JM</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.userName}>John Mwangi Kamau</Text>
            <Text style={styles.userPhone}>+254 700 123 456</Text>
            <View style={styles.verifiedRow}>
              <MaterialCommunityIcons name="check-decagram" size={14} color={COLORS.greenLight} />
              <Text style={styles.verifiedText}>KRA Verified · NTSA Linked</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.editAvatarBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="pencil" size={16} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {[
            { label: 'Permits',    value: '4',  icon: 'card-multiple',  color: COLORS.primary  },
            { label: 'Countries',  value: '3',  icon: 'earth',          color: COLORS.green    },
            { label: 'Crossings',  value: '12', icon: 'road-variant',   color: '#7B1FA2'       },
          ].map(({ label, value, icon, color }) => (
            <View key={label} style={styles.statCard}>
              <MaterialCommunityIcons name={icon} size={20} color={color} />
              <Text style={[styles.statNum, { color }]}>{value}</Text>
              <Text style={styles.statLabel}>{label}</Text>
            </View>
          ))}
        </View>

        {/* Compliance score */}
        <View style={styles.complianceCard}>
          <View style={styles.complianceLeft}>
            <MaterialCommunityIcons name="shield-star" size={22} color={COLORS.greenLight} />
            <View>
              <Text style={styles.complianceTitle}>Compliance Score</Text>
              <Text style={styles.complianceSub}>Excellent traveller record</Text>
            </View>
          </View>
          <Text style={styles.complianceScore}>96</Text>
        </View>

        {/* Menu sections */}
        {MENU.map(section => (
          <View key={section.section} style={styles.menuSection}>
            <Text style={styles.menuSectionTitle}>{section.section}</Text>
            <View style={styles.menuCard}>
              {section.items.map((item, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.menuItem, i < section.items.length - 1 && styles.menuItemBorder]}
                  onPress={item.toggle ? undefined : item.onPress}
                  activeOpacity={item.toggle ? 1 : 0.8}
                >
                  <View style={[styles.menuItemIcon, { backgroundColor: COLORS.infoBg }]}>
                    <MaterialCommunityIcons name={item.icon} size={18} color={item.muted ? COLORS.textMuted : COLORS.primary} />
                  </View>
                  <Text style={[styles.menuItemLabel, item.muted && { color: COLORS.textMuted }]}>{item.label}</Text>
                  {item.badge && <Text style={styles.menuItemBadge}>{item.badge}</Text>}
                  {item.toggle
                    ? <Switch value={item.value} onValueChange={item.onToggle} trackColor={{ true: COLORS.primary }} thumbColor={COLORS.white} />
                    : !item.muted && <MaterialCommunityIcons name="chevron-right" size={18} color={COLORS.textLight} />
                  }
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Logout */}
        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={() => navigation.replace('Login')}
          activeOpacity={0.88}
        >
          <MaterialCommunityIcons name="logout" size={18} color={COLORS.red} />
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:          { flex: 1, backgroundColor: COLORS.background },
  header:             { backgroundColor: COLORS.primary, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16 },
  headerTitle:        { fontSize: 22, fontWeight: '800', color: COLORS.white },
  avatarCard:         { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORS.white, margin: 16, borderRadius: RADIUS.xl, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  avatar:             { width: 60, height: 60, borderRadius: 30, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  avatarInitials:     { fontSize: 22, fontWeight: '800', color: COLORS.white },
  userName:           { fontSize: 17, fontWeight: '800', color: COLORS.textPrimary, marginBottom: 2 },
  userPhone:          { fontSize: 13, color: COLORS.textMuted, marginBottom: 5 },
  verifiedRow:        { flexDirection: 'row', alignItems: 'center', gap: 4 },
  verifiedText:       { fontSize: 11, color: COLORS.greenLight, fontWeight: '600' },
  editAvatarBtn:      { width: 32, height: 32, borderRadius: 16, backgroundColor: COLORS.infoBg, alignItems: 'center', justifyContent: 'center' },
  statsRow:           { flexDirection: 'row', gap: 10, marginHorizontal: 16, marginBottom: 12 },
  statCard:           { flex: 1, backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: 12, alignItems: 'center', gap: 4, borderWidth: 1, borderColor: COLORS.border },
  statNum:            { fontSize: 22, fontWeight: '900' },
  statLabel:          { fontSize: 10, color: COLORS.textMuted, fontWeight: '500' },
  complianceCard:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.successBg, marginHorizontal: 16, borderRadius: RADIUS.lg, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(0,200,83,0.2)' },
  complianceLeft:     { flexDirection: 'row', alignItems: 'center', gap: 10 },
  complianceTitle:    { fontSize: 14, fontWeight: '700', color: COLORS.green },
  complianceSub:      { fontSize: 11, color: COLORS.green, opacity: 0.7, marginTop: 1 },
  complianceScore:    { fontSize: 34, fontWeight: '900', color: COLORS.greenLight },
  menuSection:        { marginHorizontal: 16, marginBottom: 14 },
  menuSectionTitle:   { fontSize: 11, fontWeight: '700', color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 },
  menuCard:           { backgroundColor: COLORS.white, borderRadius: RADIUS.lg, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  menuItem:           { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 13 },
  menuItemBorder:     { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  menuItemIcon:       { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  menuItemLabel:      { flex: 1, fontSize: 14, color: COLORS.textPrimary, fontWeight: '500' },
  menuItemBadge:      { fontSize: 12, color: COLORS.textMuted, marginRight: 4 },
  logoutBtn:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginHorizontal: 16, marginTop: 4, height: 50, borderRadius: RADIUS.lg, borderWidth: 1.5, borderColor: COLORS.errorBg, backgroundColor: COLORS.white },
  logoutText:         { fontSize: 15, fontWeight: '700', color: COLORS.red },
});
