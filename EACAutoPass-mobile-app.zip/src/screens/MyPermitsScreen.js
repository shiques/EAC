import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS } from '../constants/theme';

const SAMPLE_PERMITS = [
  { id: 'EAC-TIP-20491', type: 'Temporary Import',  plate: 'KBZ 382 G', route: 'Kenya → Uganda',   issued: '1 Jun 2025',  expires: '30 Jun 2025', status: 'valid'    },
  { id: 'EAC-TEP-10322', type: 'Temporary Export',  plate: 'KDA 101 K', route: 'Kenya → Tanzania', issued: '20 May 2025', expires: '15 Jun 2025', status: 'expiring' },
  { id: 'EAC-TRP-09811', type: 'Transit Permit',    plate: 'KCC 777 T', route: 'Kenya → Rwanda',   issued: '10 Apr 2025', expires: '10 May 2025', status: 'expired'  },
  { id: 'EAC-CAR-00321', type: 'Carnet de Passages',plate: 'KBX 220 Z', route: 'Multi-country EAC',issued: '1 Jan 2025',  expires: '31 Dec 2025', status: 'valid'    },
];

const STATUS_CONFIG = {
  valid:    { label: 'VALID',    color: COLORS.greenLight, bg: COLORS.successBg },
  expiring: { label: 'EXPIRING', color: COLORS.gold,       bg: COLORS.warningBg },
  expired:  { label: 'EXPIRED',  color: COLORS.red,        bg: COLORS.errorBg   },
};

const FILTERS = ['All', 'Valid', 'Expiring', 'Expired'];

export default function MyPermitsScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [filter, setFilter] = useState('All');

  const filtered = SAMPLE_PERMITS.filter(p => {
    if (filter === 'All') return true;
    return p.status === filter.toLowerCase();
  });

  const renderItem = ({ item }) => {
    const cfg = STATUS_CONFIG[item.status];
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('Permit', { permitId: item.id, application: { name: 'John Mwangi', plate: item.plate, make: 'Toyota', model: 'Prado', entryBorder: item.route.split('→')[0].trim(), exitBorder: item.route.split('→')[1]?.trim() || '', permit: { label: item.type } } })}
        activeOpacity={0.85}
      >
        <View style={styles.cardLeft}>
          <View style={[styles.statusDot, { backgroundColor: cfg.color }]} />
          <View style={{ flex: 1 }}>
            <Text style={styles.cardType}>{item.type}</Text>
            <Text style={styles.cardPlate}>{item.plate}</Text>
            <Text style={styles.cardRoute}>{item.route}</Text>
          </View>
        </View>
        <View style={styles.cardRight}>
          <View style={[styles.badge, { backgroundColor: cfg.bg }]}>
            <Text style={[styles.badgeText, { color: cfg.color }]}>{cfg.label}</Text>
          </View>
          <Text style={styles.cardExpiry}>Exp: {item.expires}</Text>
          <MaterialCommunityIcons name="chevron-right" size={18} color={COLORS.textMuted} />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Permits</Text>
        <TouchableOpacity
          style={styles.newBtn}
          onPress={() => navigation.navigate('Apply')}
          activeOpacity={0.85}
        >
          <MaterialCommunityIcons name="plus" size={18} color={COLORS.white} />
          <Text style={styles.newBtnText}>New</Text>
        </TouchableOpacity>
      </View>

      {/* Filters */}
      <View style={styles.filtersRow}>
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
            activeOpacity={0.8}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        {[
          { label: 'Total',    value: SAMPLE_PERMITS.length,                             color: COLORS.primary },
          { label: 'Active',   value: SAMPLE_PERMITS.filter(p => p.status === 'valid').length,    color: COLORS.greenLight },
          { label: 'Expiring', value: SAMPLE_PERMITS.filter(p => p.status === 'expiring').length, color: COLORS.gold },
          { label: 'Expired',  value: SAMPLE_PERMITS.filter(p => p.status === 'expired').length,  color: COLORS.red },
        ].map(({ label, value, color }) => (
          <View key={label} style={styles.statCard}>
            <Text style={[styles.statNum, { color }]}>{value}</Text>
            <Text style={styles.statLabel}>{label}</Text>
          </View>
        ))}
      </View>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={i => i.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24, gap: 10 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="file-remove-outline" size={52} color={COLORS.textLight} />
            <Text style={styles.emptyText}>No {filter.toLowerCase()} permits</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.background },
  header:          { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORS.primary, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14 },
  headerTitle:     { fontSize: 22, fontWeight: '800', color: COLORS.white },
  newBtn:          { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: RADIUS.full },
  newBtnText:      { fontSize: 13, fontWeight: '700', color: COLORS.white },
  filtersRow:      { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  filterChip:      { paddingHorizontal: 14, paddingVertical: 6, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.background },
  filterChipActive:{ backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  filterText:      { fontSize: 13, color: COLORS.textMuted, fontWeight: '500' },
  filterTextActive:{ color: COLORS.white, fontWeight: '700' },
  statsRow:        { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingVertical: 12 },
  statCard:        { flex: 1, backgroundColor: COLORS.white, borderRadius: RADIUS.md, padding: 10, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  statNum:         { fontSize: 22, fontWeight: '900' },
  statLabel:       { fontSize: 10, color: COLORS.textMuted, fontWeight: '500', marginTop: 2 },
  card:            { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  cardLeft:        { flexDirection: 'row', alignItems: 'flex-start', gap: 10, flex: 1 },
  statusDot:       { width: 8, height: 8, borderRadius: 4, marginTop: 5, flexShrink: 0 },
  cardType:        { fontSize: 12, fontWeight: '600', color: COLORS.textSecondary, marginBottom: 2 },
  cardPlate:       { fontSize: 16, fontWeight: '900', color: COLORS.primary, letterSpacing: 1.5, marginBottom: 2 },
  cardRoute:       { fontSize: 12, color: COLORS.textMuted },
  cardRight:       { alignItems: 'flex-end', gap: 5 },
  badge:           { paddingHorizontal: 8, paddingVertical: 3, borderRadius: RADIUS.full },
  badgeText:       { fontSize: 9, fontWeight: '800', letterSpacing: 0.8 },
  cardExpiry:      { fontSize: 11, color: COLORS.textMuted },
  empty:           { alignItems: 'center', paddingTop: 60, gap: 10 },
  emptyText:       { fontSize: 15, color: COLORS.textMuted },
});
