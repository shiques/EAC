import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export default function LoginScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [phone,    setPhone]    = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  const handleLogin = async () => {
    if (!phone || !password) {
      setError('Please enter your phone number and password.');
      return;
    }
    setError('');
    setLoading(true);
    // Simulate auth
    setTimeout(() => {
      setLoading(false);
      navigation.replace('Main');
    }, 1400);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={[styles.container, { paddingTop: insets.top + 20 }]}
        contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoBadge}>
            <Text style={styles.logoBadgeText}>EAC</Text>
          </View>
          <Text style={styles.logoText}>Auto<Text style={{ color: COLORS.gold }}>Pass</Text></Text>
          <Text style={styles.subtitle}>Sign in to your account</Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          {error ? (
            <View style={styles.errorBox}>
              <MaterialCommunityIcons name="alert-circle" size={16} color={COLORS.red} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Phone / ID Number</Text>
            <View style={styles.inputWrap}>
              <MaterialCommunityIcons name="phone" size={18} color={COLORS.textMuted} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="+254 700 000 000"
                placeholderTextColor={COLORS.textLight}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                autoCapitalize="none"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Password</Text>
            <View style={styles.inputWrap}>
              <MaterialCommunityIcons name="lock" size={18} color={COLORS.textMuted} style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { flex: 1 }]}
                placeholder="Enter password"
                placeholderTextColor={COLORS.textLight}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPass}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowPass(!showPass)} style={styles.eyeBtn}>
                <MaterialCommunityIcons
                  name={showPass ? 'eye-off' : 'eye'}
                  size={18}
                  color={COLORS.textMuted}
                />
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity style={styles.forgotBtn} activeOpacity={0.7}>
            <Text style={styles.forgotText}>Forgot password?</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.btnLogin, loading && { opacity: 0.75 }]}
            onPress={handleLogin}
            activeOpacity={0.85}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color={COLORS.white} size="small" />
              : <Text style={styles.btnLoginText}>Sign In</Text>
            }
          </TouchableOpacity>

          {/* Biometric */}
          <TouchableOpacity style={styles.biometricBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="fingerprint" size={28} color={COLORS.primary} />
            <Text style={styles.biometricText}>Sign in with biometrics</Text>
          </TouchableOpacity>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>New to EAC AutoPass?</Text>
            <View style={styles.dividerLine} />
          </View>

          <TouchableOpacity
            style={styles.btnRegister}
            onPress={() => navigation.navigate('Register')}
            activeOpacity={0.85}
          >
            <Text style={styles.btnRegisterText}>Create Account</Text>
          </TouchableOpacity>
        </View>

        {/* Trust badges */}
        <View style={styles.trustRow}>
          {['🇰🇪 KRA', '🛡️ COMESA', '🔒 Encrypted'].map((t, i) => (
            <View key={i} style={styles.trustBadge}>
              <Text style={styles.trustText}>{t}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.white },
  header:       { alignItems: 'center', paddingHorizontal: 24, marginBottom: 32 },
  logoBadge:    {
    width: 56, height: 56, borderRadius: 16,
    backgroundColor: COLORS.primary,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 10,
  },
  logoBadgeText: { fontSize: 18, fontWeight: '900', color: COLORS.white, letterSpacing: 1 },
  logoText:     { fontSize: 28, fontWeight: '800', color: COLORS.textPrimary, letterSpacing: 1 },
  subtitle:     { fontSize: 14, color: COLORS.textMuted, marginTop: 6 },
  form:         { paddingHorizontal: 24 },
  errorBox:     {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: COLORS.errorBg, borderRadius: RADIUS.md,
    padding: 12, marginBottom: 16,
  },
  errorText:    { fontSize: 13, color: COLORS.red, flex: 1 },
  inputGroup:   { marginBottom: 16 },
  inputLabel:   { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  inputWrap:    {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1.5, borderColor: COLORS.border,
    borderRadius: RADIUS.md, backgroundColor: COLORS.background,
    paddingHorizontal: 12, height: 50,
  },
  inputIcon:    { marginRight: 8 },
  input:        { flex: 1, fontSize: 15, color: COLORS.textPrimary },
  eyeBtn:       { padding: 4 },
  forgotBtn:    { alignSelf: 'flex-end', marginBottom: 24 },
  forgotText:   { fontSize: 13, color: COLORS.primary, fontWeight: '600' },
  btnLogin:     {
    height: 52, backgroundColor: COLORS.primary,
    borderRadius: RADIUS.lg, alignItems: 'center', justifyContent: 'center',
    marginBottom: 16,
  },
  btnLoginText: { fontSize: 16, fontWeight: '700', color: COLORS.white, letterSpacing: 0.3 },
  biometricBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 10, height: 48,
    borderWidth: 1.5, borderColor: COLORS.border,
    borderRadius: RADIUS.lg, marginBottom: 28,
  },
  biometricText: { fontSize: 14, color: COLORS.primary, fontWeight: '600' },
  divider:      { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16 },
  dividerLine:  { flex: 1, height: 1, backgroundColor: COLORS.border },
  dividerText:  { fontSize: 12, color: COLORS.textMuted },
  btnRegister:  {
    height: 52, borderWidth: 1.5, borderColor: COLORS.primary,
    borderRadius: RADIUS.lg, alignItems: 'center', justifyContent: 'center',
  },
  btnRegisterText: { fontSize: 16, fontWeight: '700', color: COLORS.primary },
  trustRow:     { flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 28, paddingHorizontal: 24 },
  trustBadge:   {
    paddingHorizontal: 10, paddingVertical: 5,
    backgroundColor: COLORS.background,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border,
  },
  trustText:    { fontSize: 11, color: COLORS.textSecondary, fontWeight: '500' },
});
