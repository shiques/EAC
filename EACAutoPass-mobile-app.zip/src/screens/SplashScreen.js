import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Dimensions,
} from 'react-native';
import { COLORS } from '../constants/theme';

const { width } = Dimensions.get('window');

export default function SplashScreen({ navigation }) {
  const logoScale  = useRef(new Animated.Value(0.5)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const lineWidth   = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(logoScale,   { toValue: 1, tension: 60, friction: 7, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(textOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(lineWidth,   { toValue: 120, duration: 600, useNativeDriver: false }),
      ]),
    ]).start();

    const timer = setTimeout(() => navigation.replace('Onboarding'), 2600);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      {/* Background stripes */}
      <View style={styles.stripesWrap}>
        {[COLORS.primary, COLORS.green, COLORS.gold, '#1a1a1a', COLORS.red].map((c, i) => (
          <View key={i} style={[styles.stripe, { backgroundColor: c, transform: [{ skewX: '-15deg' }] }]} />
        ))}
      </View>

      {/* Logo area */}
      <Animated.View style={[styles.logoWrap, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}>
        <View style={styles.logoBox}>
          <Text style={styles.logoEAC}>EAC</Text>
          <Animated.View style={[styles.logoLine, { width: lineWidth }]} />
        </View>
        <Animated.Text style={[styles.logoSub, { opacity: textOpacity }]}>
          AUTO<Text style={{ color: COLORS.gold }}>PASS</Text>
        </Animated.Text>
      </Animated.View>

      <Animated.Text style={[styles.tagline, { opacity: textOpacity }]}>
        Smart Cross-Border Movement
      </Animated.Text>

      {/* Country flags */}
      <Animated.View style={[styles.flags, { opacity: textOpacity }]}>
        {['🇰🇪','🇺🇬','🇹🇿','🇷🇼','🇧🇮','🇸🇸','🇨🇩'].map((f, i) => (
          <Text key={i} style={styles.flag}>{f}</Text>
        ))}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:           1,
    backgroundColor:COLORS.primaryDark,
    alignItems:     'center',
    justifyContent: 'center',
  },
  stripesWrap: {
    position:   'absolute',
    top:        0, left: -40, right: -40, bottom: 0,
    flexDirection:'row',
    overflow:   'hidden',
    opacity:    0.12,
  },
  stripe: {
    flex:   1,
    marginHorizontal: 4,
  },
  logoWrap: {
    alignItems: 'center',
    marginBottom: 16,
  },
  logoBox: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           8,
    marginBottom:  6,
  },
  logoEAC: {
    fontSize:    52,
    fontWeight:  '900',
    color:       COLORS.white,
    letterSpacing:4,
  },
  logoLine: {
    height:          4,
    backgroundColor: COLORS.gold,
    borderRadius:    2,
  },
  logoSub: {
    fontSize:    28,
    fontWeight:  '800',
    color:       COLORS.white,
    letterSpacing:6,
  },
  tagline: {
    fontSize:    14,
    color:       'rgba(255,255,255,0.65)',
    letterSpacing:2,
    textTransform:'uppercase',
    marginBottom: 60,
  },
  flags: {
    flexDirection: 'row',
    gap:           12,
    position:      'absolute',
    bottom:        60,
  },
  flag: {
    fontSize: 22,
  },
});
