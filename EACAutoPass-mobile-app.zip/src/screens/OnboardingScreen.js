import React, { useRef, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Dimensions, Animated,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

const { width } = Dimensions.get('window');

const SLIDES = [
  {
    id:    '1',
    icon:  'passport',
    color: COLORS.primary,
    title: 'Cross borders smarter',
    desc:  'Apply for temporary import, export, and transit permits online — before you even leave home.',
  },
  {
    id:    '2',
    icon:  'qrcode-scan',
    color: COLORS.green,
    title: 'QR code at the border',
    desc:  'Receive a digital permit with a scannable QR code. Border officers clear you in under 2 minutes.',
  },
  {
    id:    '3',
    icon:  'cellphone-nfc',
    color: '#7B1FA2',
    title: 'Pay with M-Pesa or card',
    desc:  'Pay permit fees instantly via M-Pesa STK push, Visa, Mastercard, or mobile money.',
  },
  {
    id:    '4',
    icon:  'shield-check',
    color: COLORS.red,
    title: 'Trusted by EAC authorities',
    desc:  'Fully compliant with EACCMA and COMESA frameworks. Integrated with KRA, NTSA and border agencies.',
  },
];

export default function OnboardingScreen({ navigation }) {
  const insets    = useSafeAreaInsets();
  const flatRef   = useRef(null);
  const [index, setIndex]   = useState(0);

  const goNext = () => {
    if (index < SLIDES.length - 1) {
      flatRef.current?.scrollToIndex({ index: index + 1, animated: true });
    } else {
      navigation.replace('Login');
    }
  };

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom + 20 }]}>
      <FlatList
        ref={flatRef}
        data={SLIDES}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={e => {
          const newIdx = Math.round(e.nativeEvent.contentOffset.x / width);
          setIndex(newIdx);
        }}
        renderItem={({ item }) => (
          <View style={styles.slide}>
            <View style={[styles.iconCircle, { backgroundColor: item.color + '18' }]}>
              <MaterialCommunityIcons name={item.icon} size={72} color={item.color} />
            </View>
            <Text style={styles.slideTitle}>{item.title}</Text>
            <Text style={styles.slideDesc}>{item.desc}</Text>
          </View>
        )}
        keyExtractor={i => i.id}
      />

      {/* Dots */}
      <View style={styles.dots}>
        {SLIDES.map((_, i) => (
          <View
            key={i}
            style={[styles.dot, i === index && styles.dotActive]}
          />
        ))}
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.btnPrimary} onPress={goNext} activeOpacity={0.85}>
          <Text style={styles.btnPrimaryText}>
            {index === SLIDES.length - 1 ? 'Get Started' : 'Next'}
          </Text>
          <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.white} />
        </TouchableOpacity>

        {index < SLIDES.length - 1 && (
          <TouchableOpacity onPress={() => navigation.replace('Login')} activeOpacity={0.7}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:            1,
    backgroundColor: COLORS.white,
    paddingTop:      60,
  },
  slide: {
    width,
    alignItems:     'center',
    paddingHorizontal: 36,
    paddingTop:     24,
  },
  iconCircle: {
    width:         160,
    height:        160,
    borderRadius:  80,
    alignItems:    'center',
    justifyContent:'center',
    marginBottom:  40,
  },
  slideTitle: {
    fontSize:    26,
    fontWeight:  '800',
    color:       COLORS.textPrimary,
    textAlign:   'center',
    marginBottom:16,
    letterSpacing:-0.3,
  },
  slideDesc: {
    fontSize:    15,
    color:       COLORS.textSecondary,
    textAlign:   'center',
    lineHeight:  23,
  },
  dots: {
    flexDirection:  'row',
    justifyContent: 'center',
    gap:            8,
    marginTop:      32,
    marginBottom:   24,
  },
  dot: {
    width:        7,
    height:       7,
    borderRadius: 4,
    backgroundColor: COLORS.border,
  },
  dotActive: {
    width:           20,
    backgroundColor: COLORS.primary,
  },
  actions: {
    paddingHorizontal: 24,
    gap: 14,
    alignItems: 'center',
  },
  btnPrimary: {
    width:           '100%',
    height:          52,
    backgroundColor: COLORS.primary,
    borderRadius:    RADIUS.lg,
    flexDirection:   'row',
    alignItems:      'center',
    justifyContent:  'center',
    gap:             8,
  },
  btnPrimaryText: {
    fontSize:    16,
    fontWeight:  '700',
    color:       COLORS.white,
    letterSpacing:0.3,
  },
  skipText: {
    fontSize:  14,
    color:     COLORS.textMuted,
    fontWeight:'500',
  },
});
