import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS } from '../constants/theme';

export default function ScannerScreen() {
  const insets = useSafeAreaInsets();
  const [result, setResult] = useState(null);

  const simulateScan = () => {
    setResult({
      permitId:  'EAC-TIP-20491',
      holder:    'John Mwangi Kamau',
      plate:     'KBZ 382 G',
      vehicle:   'Toyota Prado TX',
      route:     'Kenya → Uganda',
      status:    'APPROVED',
      valid:     true,
      expires:   '30 Jun 2025',
      insurance: 'Verified',
      risk:      'LOW',
    });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Border Scanner</Text>
        <Text style={styles.headerSub}>ANPR / QR / RFID verification</Text>
      </View>

      {!result ? (
        <View style={styles.scanArea}>
          <View style={styles.viewfinder}>
            <View style={[styles.corner, styles.cornerTL]} />
            <View style={[styles.corner, styles.cornerTR]} />
            <View style={[styles.corner, styles.cornerBL]} />
            <View style={[styles.corner, styles.cornerBR]} />
            <View style={styles.scanLine} />
            <MaterialCommunityIcons name="qrcode-scan" size={52} color="rgba(255,255,255,0.3)" />
            <Text style={styles.scanPrompt}>Point camera at permit QR code</Text>
          </View>

          <View style={styles.manualEntry}>
            <Text style={styles.manualTitle}>Or enter plate / permit ID manually</Text>
            <TouchableOpacity style={styles.simulateBtn} onPress={simulateScan} activeOpacity={0.85}>
              <MaterialCommunityIcons name="magnify" size={18} color={COLORS.white} />
              <Text style={styles.simulateBtnText}>Simulate Scan: KBZ 382 G</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.methodsRow}>
            {[
              { icon: 'camera', label: 'ANPR',  color: COLORS.primary },
              { icon: 'qrcode', label: 'QR',    color: COLORS.green   },
              { icon: 'nfc',    label: 'NFC',   color: '#7B1FA2'      },
              { icon: 'wifi',   label: 'RFID',  color: COLORS.gold    },
            ].map(m => (
              <View key={m.label} style={styles.methodCard}>
                <MaterialCommunityIcons name={m.icon} size={22} color={m.color} />
                <Text style={styles.methodLabel}>{m.label}</Text>
              </View>
            ))}
          </View>
        </View>
      ) : (
        <View style={styles.resultArea}>
          <View style={[styles.resultHeader, { backgroundColor: result.valid ? COLORS.greenLight : COLORS.red }]}>
            <MaterialCommunityIcons
              name={result.valid ? 'check-circle' : 'alert-circle'}
              size={28}
              color={COLORS.white}
            />
            <Text style={styles.resultHeaderText}>
              {result.valid ? 'PERMIT VALID — CLEAR TO PROCEED' : 'PERMIT INVALID — HOLD VEHICLE'}
            </Text>
          </View>

          <View style={styles.resultCard}>
            {[
              ['Permit ID',    result.permitId,  'card-text'       ],
              ['Holder',       result.holder,    'account'         ],
              ['Vehicle',      result.vehicle,   'car'             ],
              ['Plate No.',    result.plate,     'card-account-details'],
              ['Route',        result.route,     'map-marker-path' ],
              ['Status',       result.status,    'check-circle'    ],
              ['Expires',      result.expires,   'calendar'        ],
              ['Insurance',    result.insurance, 'shield-check'    ],
              ['Risk Score',   result.risk,      'gauge'           ],
            ].map(([label, value, icon], i) => (
              <View key={i} style={[styles.resultRow, i % 2 === 0 && styles.resultRowAlt]}>
                <View style={styles.resultRowLeft}>
                  <MaterialCommunityIcons name={icon} size={14} color={COLORS.primary} />
                  <Text style={styles.resultLabel}>{label}</Text>
                </View>
                <Text style={[
                  styles.resultValue,
                  (value === 'APPROVED' || value === 'Verified' || value === 'LOW') && { color: COLORS.greenLight },
                ]} numberOfLines={1}>{value}</Text>
              </View>
            ))}
          </View>

          <View style={styles.resultActions}>
            <TouchableOpacity style={styles.btnLog} activeOpacity={0.85}>
              <MaterialCommunityIcons name="clipboard-check" size={16} color={COLORS.primary} />
              <Text style={styles.btnLogText}>Log Entry</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.btnNewScan}
              onPress={() => setResult(null)}
              activeOpacity={0.88}
            >
              <MaterialCommunityIcons name="camera-retake" size={16} color={COLORS.white} />
              <Text style={styles.btnNewScanText}>New Scan</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#0D1B3E' },
  header:          { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14 },
  headerTitle:     { fontSize: 22, fontWeight: '800', color: COLORS.white },
  headerSub:       { fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 },
  scanArea:        { flex: 1, padding: 16, gap: 20 },
  viewfinder:      { aspectRatio: 1, maxHeight: 280, backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: RADIUS.xl, alignItems: 'center', justifyContent: 'center', position: 'relative', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', gap: 10 },
  corner:          { position: 'absolute', width: 28, height: 28, borderColor: COLORS.gold, borderWidth: 3 },
  cornerTL:        { top: 12, left: 12, borderRightWidth: 0, borderBottomWidth: 0 },
  cornerTR:        { top: 12, right: 12, borderLeftWidth: 0, borderBottomWidth: 0 },
  cornerBL:        { bottom: 12, left: 12, borderRightWidth: 0, borderTopWidth: 0 },
  cornerBR:        { bottom: 12, right: 12, borderLeftWidth: 0, borderTopWidth: 0 },
  scanLine:        { position: 'absolute', left: 12, right: 12, height: 2, backgroundColor: COLORS.gold, opacity: 0.7 },
  scanPrompt:      { fontSize: 12, color: 'rgba(255,255,255,0.45)', textAlign: 'center' },
  manualEntry:     { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: RADIUS.lg, padding: 16, gap: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  manualTitle:     { fontSize: 13, color: 'rgba(255,255,255,0.6)', textAlign: 'center' },
  simulateBtn:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, height: 46, borderRadius: RADIUS.lg },
  simulateBtnText: { fontSize: 14, fontWeight: '700', color: COLORS.white },
  methodsRow:      { flexDirection: 'row', gap: 10 },
  methodCard:      { flex: 1, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: RADIUS.md, padding: 12, alignItems: 'center', gap: 6, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  methodLabel:     { fontSize: 11, color: 'rgba(255,255,255,0.6)', fontWeight: '600' },
  resultArea:      { flex: 1 },
  resultHeader:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 14, paddingHorizontal: 16 },
  resultHeaderText:{ fontSize: 13, fontWeight: '800', color: COLORS.white, flex: 1 },
  resultCard:      { backgroundColor: COLORS.white, margin: 16, borderRadius: RADIUS.xl, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  resultRow:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 9, paddingHorizontal: 14 },
  resultRowAlt:    { backgroundColor: COLORS.background },
  resultRowLeft:   { flexDirection: 'row', alignItems: 'center', gap: 7 },
  resultLabel:     { fontSize: 12, color: COLORS.textSecondary },
  resultValue:     { fontSize: 13, fontWeight: '700', color: COLORS.textPrimary, flex: 1, textAlign: 'right' },
  resultActions:   { flexDirection: 'row', gap: 10, marginHorizontal: 16 },
  btnLog:          { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, height: 48, borderRadius: RADIUS.lg, borderWidth: 1.5, borderColor: COLORS.primary, backgroundColor: COLORS.white },
  btnLogText:      { fontSize: 14, fontWeight: '700', color: COLORS.primary },
  btnNewScan:      { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, height: 48, borderRadius: RADIUS.lg, backgroundColor: COLORS.primary },
  btnNewScanText:  { fontSize: 14, fontWeight: '700', color: COLORS.white },
});
