import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, RADIUS } from '../constants/theme';

export default function RegisterScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [name,     setName]     = useState('');
  const [phone,    setPhone]    = useState('');
  const [email,    setEmail]    = useState('');
  const [idNum,    setIdNum]    = useState('');
  const [password, setPassword] = useState('');
  const [confirm,  setConfirm]  = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [errors,   setErrors]   = useState({});

  const validate = () => {
    const e = {};
    if (!name.trim())    e.name    = 'Full name is required';
    if (!phone.trim())   e.phone   = 'Phone number is required';
    if (!idNum.trim())   e.idNum   = 'ID / Passport number is required';
    if (!password)       e.password= 'Password is required';
    else if (password.length < 6) e.password = 'Password must be at least 6 characters';
    if (password !== confirm) e.confirm = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = () => {
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigation.replace('Main');
    }, 1600);
  };

  const field = (label, value, onChange, opts = {}) => (
    <View style={styles.fieldGroup}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.inputWrap, opts.error && styles.inputWrapError]}>
        {opts.icon && (
          <MaterialCommunityIcons name={opts.icon} size={18} color={COLORS.textMuted} style={styles.icon} />
        )}
        <TextInput
          style={[styles.input, opts.flex && { flex: 1 }]}
          value={value}
          onChangeText={onChange}
          placeholder={opts.placeholder || ''}
          placeholderTextColor={COLORS.textLight}
          keyboardType={opts.keyboard || 'default'}
          secureTextEntry={opts.secure && !showPass}
          autoCapitalize={opts.caps || 'sentences'}
        />
        {opts.toggleEye && (
          <TouchableOpacity onPress={() => setShowPass(v => !v)} style={styles.eyeBtn}>
            <MaterialCommunityIcons name={showPass ? 'eye-off' : 'eye'} size={18} color={COLORS.textMuted} />
          </TouchableOpacity>
        )}
      </View>
      {opts.error && <Text style={styles.errText}>{opts.error}</Text>}
    </View>
  );

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        style={[styles.container, { paddingTop: insets.top }]}
        contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="arrow-left" size={22} color={COLORS.white} />
          </TouchableOpacity>
          <View>
            <Text style={styles.headerTitle}>Create Account</Text>
            <Text style={styles.headerSub}>Join EAC AutoPass today</Text>
          </View>
        </View>

        <View style={styles.form}>
          {field('Full Name *', name, setName, { icon: 'account', placeholder: 'e.g. John Mwangi Kamau', error: errors.name })}
          {field('Phone Number *', phone, setPhone, { icon: 'phone', placeholder: '+254 700 000 000', keyboard: 'phone-pad', error: errors.phone })}
          {field('ID / Passport Number *', idNum, setIdNum, { icon: 'card-account-details', placeholder: 'e.g. A1234567', caps: 'characters', error: errors.idNum })}
          {field('Email (optional)', email, setEmail, { icon: 'email', placeholder: 'john@example.com', keyboard: 'email-address', caps: 'none' })}
          {field('Password *', password, setPassword, { icon: 'lock', placeholder: 'At least 6 characters', secure: true, toggleEye: true, flex: true, error: errors.password })}
          {field('Confirm Password *', confirm, setConfirm, { icon: 'lock-check', placeholder: 'Re-enter password', secure: true, flex: true, error: errors.confirm })}

          {/* Terms */}
          <Text style={styles.termsText}>
            By creating an account you agree to EAC AutoPass{' '}
            <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
            <Text style={styles.termsLink}>Privacy Policy</Text>.
          </Text>

          <TouchableOpacity
            style={[styles.btnCreate, loading && { opacity: 0.75 }]}
            onPress={handleRegister}
            activeOpacity={0.88}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color={COLORS.white} size="small" />
              : <Text style={styles.btnCreateText}>Create Account</Text>
            }
          </TouchableOpacity>

          <TouchableOpacity style={styles.signInRow} onPress={() => navigation.navigate('Login')} activeOpacity={0.7}>
            <Text style={styles.signInText}>Already have an account? </Text>
            <Text style={styles.signInLink}>Sign In</Text>
          </TouchableOpacity>
        </View>

        {/* Trust strip */}
        <View style={styles.trustStrip}>
          {['🔒 Encrypted', '🇰🇪 KRA Verified', '🌍 COMESA Compliant'].map((t, i) => (
            <View key={i} style={styles.trustTag}>
              <Text style={styles.trustTagText}>{t}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.white },
  header:         { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: COLORS.primary, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 20 },
  backBtn:        { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  headerTitle:    { fontSize: 20, fontWeight: '800', color: COLORS.white },
  headerSub:      { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  form:           { padding: 20 },
  fieldGroup:     { marginBottom: 14 },
  label:          { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  inputWrap:      { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.background, borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.md, paddingHorizontal: 12, height: 50 },
  inputWrapError: { borderColor: COLORS.red },
  icon:           { marginRight: 8 },
  input:          { flex: 1, fontSize: 14, color: COLORS.textPrimary },
  eyeBtn:         { padding: 4 },
  errText:        { fontSize: 11, color: COLORS.red, marginTop: 4 },
  termsText:      { fontSize: 12, color: COLORS.textMuted, lineHeight: 18, marginBottom: 20, textAlign: 'center' },
  termsLink:      { color: COLORS.primary, fontWeight: '600' },
  btnCreate:      { height: 52, backgroundColor: COLORS.primary, borderRadius: RADIUS.lg, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  btnCreateText:  { fontSize: 16, fontWeight: '700', color: COLORS.white },
  signInRow:      { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  signInText:     { fontSize: 14, color: COLORS.textMuted },
  signInLink:     { fontSize: 14, color: COLORS.primary, fontWeight: '700' },
  trustStrip:     { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 20, paddingHorizontal: 20, flexWrap: 'wrap' },
  trustTag:       { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: COLORS.background, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border },
  trustTagText:   { fontSize: 11, color: COLORS.textSecondary, fontWeight: '500' },
});
