import React, { useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { COLORS, FONTS } from '../constants/theme';

// Screens
import SplashScreen     from '../screens/SplashScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import LoginScreen      from '../screens/LoginScreen';
import RegisterScreen   from '../screens/RegisterScreen';
import HomeScreen       from '../screens/HomeScreen';
import ApplyScreen      from '../screens/ApplyScreen';
import PaymentScreen    from '../screens/PaymentScreen';
import PermitScreen     from '../screens/PermitScreen';
import MyPermitsScreen  from '../screens/MyPermitsScreen';
import ProfileScreen    from '../screens/ProfileScreen';
import ScannerScreen    from '../screens/ScannerScreen';

const Stack = createStackNavigator();
const Tab   = createBottomTabNavigator();

function TabBar({ state, descriptors, navigation }) {
  const tabs = [
    { route: 'Home',      icon: 'home',             label: 'Home'    },
    { route: 'Apply',     icon: 'file-plus-outline', label: 'Apply'   },
    { route: 'MyPermits', icon: 'card-multiple',     label: 'Permits' },
    { route: 'Scanner',   icon: 'qrcode-scan',       label: 'Scan'    },
    { route: 'Profile',   icon: 'account-circle',    label: 'Profile' },
  ];

  return (
    <View style={styles.tabBar}>
      {state.routes.map((route, index) => {
        const focused = state.index === index;
        const tab     = tabs.find(t => t.route === route.name);
        if (!tab) return null;

        return (
          <TouchableOpacity
            key={route.key}
            style={styles.tabItem}
            onPress={() => navigation.navigate(route.name)}
            activeOpacity={0.7}
          >
            <View style={[styles.tabIconWrap, focused && styles.tabIconWrapActive]}>
              <MaterialCommunityIcons
                name={tab.icon}
                size={focused ? 22 : 20}
                color={focused ? COLORS.primary : COLORS.textMuted}
              />
            </View>
            <Text style={[styles.tabLabel, focused && styles.tabLabelActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      tabBar={props => <TabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Home"      component={HomeScreen}      />
      <Tab.Screen name="Apply"     component={ApplyScreen}     />
      <Tab.Screen name="MyPermits" component={MyPermitsScreen} />
      <Tab.Screen name="Scanner"   component={ScannerScreen}   />
      <Tab.Screen name="Profile"   component={ProfileScreen}   />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash"     component={SplashScreen}     />
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="Login"      component={LoginScreen}      />
      <Stack.Screen name="Register"   component={RegisterScreen}   />
      <Stack.Screen name="Main"       component={MainTabs}         />
      <Stack.Screen name="Payment"    component={PaymentScreen}    />
      <Stack.Screen name="Permit"     component={PermitScreen}     />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection:      'row',
    backgroundColor:    COLORS.white,
    borderTopWidth:     1,
    borderTopColor:     COLORS.border,
    paddingBottom:      20,
    paddingTop:         8,
    paddingHorizontal:  4,
  },
  tabItem: {
    flex:           1,
    alignItems:     'center',
    justifyContent: 'center',
    gap:            3,
  },
  tabIconWrap: {
    width:         36,
    height:        36,
    borderRadius:  18,
    alignItems:    'center',
    justifyContent:'center',
  },
  tabIconWrapActive: {
    backgroundColor: COLORS.surfaceAlt,
  },
  tabLabel: {
    fontSize:    10,
    color:       COLORS.textMuted,
    fontWeight:  '500',
    letterSpacing:0.2,
  },
  tabLabelActive: {
    color:      COLORS.primary,
    fontWeight: '700',
  },
});
